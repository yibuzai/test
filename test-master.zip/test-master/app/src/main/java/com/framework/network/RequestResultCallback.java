package com.framework.network;

/** 
 * TODO<http 请求结果回调接口> 
 * @author zqk
 * @data:  2015年8月23日 下午4:28:38 
 * @version:  V1.0 
 */
public interface RequestResultCallback {

	/**
	 * 加载成功
	 * 
	 * @param httpHandler
	 *            结果处理handler
	 * @param o
	 *            结果响应包
	 */
	public void onSuccess(HttpHandler httpHandler, Object o);

	/**
	 * 加载失败
	 * 
	 * @param httpHandler
	 *            结果处理handler
	 * @param e
	 *            异常
	 */
	public void onFail(HttpHandler httpHandler, Exception e);

}
