package com.framework.util;

import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** 
 * TODO<对象转换工具类 支持普通类型为：int、long、float、double、String、boolean、Date
 *               支持集合类型为：HashMap(key需要为String)、Set、List、array（数组） 注意事项:1.
 *               boolean类型也要用 get和set方法，而不是 is和set方法> 
 * @author zqk
 * @data:  2015年8月23日 下午4:21:50 
 * @version:  V1.0 
 */
public class ObjectTranslatorUtils {

	private static final String DATE_FLAG = "$date"; // 自定义json的Date类型标识

	// 未知类型对象转换为JSON类
	public static Object object2Json(Object obj) {
		if (obj instanceof HashMap<?, ?>) {
			return hashMap2Json((HashMap<String, Object>) obj);
		} else if (obj instanceof Set<?>) {
			return pojoSet2JsonArray((Set<?>) obj);
		} else if (obj instanceof List<?>) {
			return pojoList2JsonArray((List<?>) obj);
		} else if (obj.getClass().isArray()) {
			return pojoArray2JsonArray(obj);
		} else if (checkBaseType(obj.getClass())) {
			return obj;
		} else if (obj instanceof Date) {
			return date2Json((Date) obj);
		} else if (obj instanceof JSONObject) {
			return obj;
		} else if (obj instanceof JSONArray) {
			return obj;
		} else {
			return pojo2Json(obj);
		}
	}

	// Date转换为JSON
	public static JSONObject date2Json(Date date) {
		try {
			JSONObject json = new JSONObject();
			json.put(DATE_FLAG, date.getTime());
			return json;
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
	}

	// HashMap转换为JSON
	public static JSONObject hashMap2Json(HashMap<String, Object> hm) {
		try {
			JSONObject jsonObj = new JSONObject();
			for (String key : hm.keySet()) {
				jsonObj.put(key, object2Json(hm.get(key)));
			}
			return jsonObj;
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
	}

	// POJO Set转换为JSON数组
	public static JSONArray pojoSet2JsonArray(Set<?> set) {
		JSONArray jsonArray = new JSONArray();
		for (Object obj : set) {
			jsonArray.put(object2Json(obj));
		}
		return jsonArray;
	}

	// POJO List转换为JSON数组
	public static <T> JSONArray pojoList2JsonArray(List<T> list) {
		JSONArray jsonArray = new JSONArray();
		int length = list.size();
		for (int i = 0; i < length; i++) {
			Object obj = list.get(i);
			Object jsonObj = object2Json(obj);
			jsonArray.put(jsonObj);
		}
		return jsonArray;
	}

	// POJO数组转换为JSON数组
	public static JSONArray pojoArray2JsonArray(Object pojoArray) {
		JSONArray jsonArray = new JSONArray();
		int length = Array.getLength(pojoArray);
		for (int i = 0; i < length; i++) {
			Object obj = Array.get(pojoArray, i);
			Object jsonObj = object2Json(obj);
			jsonArray.put(jsonObj);
		}
		return jsonArray;
	}

	// POJO转换为JSON
	public static JSONObject pojo2Json(Object pojo) {
		try {
			JSONObject jsonObj = new JSONObject();
			HashMap<String, Object> hm = PojoPropertyUtils
					.getPropertysNoNull(pojo);

			for (String key : hm.keySet()) {
				Object value = hm.get(key);
				Object jsonValue = object2Json(value);
				jsonObj.put(key, jsonValue);
			}
			return jsonObj;
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
	}

	// JSON转换为POJO
	public static <T> T json2Pojo(JSONObject json, Class<T> clazz) {
		try {
			T pojo;
			if (Timestamp.class.equals(clazz)) {
				pojo = (T) new Timestamp(123);
			} else {
				pojo = clazz.newInstance();
			}

			Iterator<String> iter = json.keys();
			while (iter.hasNext()) {
				String key = iter.next();
				Object value = json.get(key);
				if (value.getClass() == JSONObject.class) {
					JSONObject jsonValue = (JSONObject) value;
					if (jsonValue.has(DATE_FLAG)) {
						Date date = new Date(
								((Number) jsonValue.get(DATE_FLAG)).longValue());
						PojoPropertyUtils.setProperty(pojo, key, date);
					} else {
						Class<?> pType = PojoPropertyUtils.getPropertyClass(
								pojo, key);
						if (pType != null) { // 过滤多余属性
							Object pValue = json2Pojo((JSONObject) value, pType);
							PojoPropertyUtils.setProperty(pojo, key, pValue);
						}
					}
				} else if (value.getClass() == JSONArray.class) {
					Type pType = PojoPropertyUtils.getPropertyType(pojo, key);
					if (pType != null) {
						Object pValue = jsonArray2Pojo((JSONArray) value, pType);
						PojoPropertyUtils.setProperty(pojo, key, pValue);
					}
				} else {
					try {
						PojoPropertyUtils.setProperty(pojo, key, value);
					} catch (Exception e) {// not handle it
					}
				}
			}
			return pojo;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	// JSON数组转换为POJO
	public static Object jsonArray2Pojo(JSONArray jsonArray, Type type)
			throws JSONException, ClassNotFoundException {
		if (type instanceof GenericArrayType) {
			GenericArrayType aType = (GenericArrayType) type;
			return jsonArray2PojoArray(jsonArray,
					aType.getGenericComponentType());
		}

		Class<?> clazz;
		if (type instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType) type;
			clazz = (Class<?>) pt.getRawType();
		} else {
			clazz = (Class<?>) type;
		}
		if (clazz.isArray()) {
			return jsonArray2PojoArray(jsonArray, clazz.getComponentType());
		} else {
			if (clazz.equals(Set.class)) {
				return jsonArray2PojoSet(jsonArray, getGenericClass(type));
			} else if (clazz.equals(List.class)) {
				return jsonArray2PojoList(jsonArray, getGenericClass(type));
			} else {
				throw new RuntimeException("not support collection type!");
			}
		}
	}

	// JSON数组转换为POJO数组
	public static Object jsonArray2PojoArray(JSONArray jsonArray, Type type)
			throws JSONException, ClassNotFoundException {
		Class<?> clazz;
		if (type instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType) type;
			clazz = (Class<?>) pt.getRawType();
		} else {
			clazz = (Class<?>) type;
		}

		Object array = Array.newInstance(clazz, jsonArray.length());
		for (int i = 0; i < jsonArray.length(); i++) {
			Object son;
			Object obj = jsonArray.get(i);
			if (obj.getClass() == JSONObject.class) {
				son = json2Pojo((JSONObject) obj, clazz);
			} else if (obj.getClass() == JSONArray.class) {
				son = jsonArray2Pojo((JSONArray) obj, type);
			} else {
				son = obj;
			}
			Array.set(array, i, son);
		}
		return array;
	}

	// JSON数组转换为POJO Set
	public static Set<Object> jsonArray2PojoSet(JSONArray jsonArray, Type type)
			throws JSONException, ClassNotFoundException {
		Set<Object> set = new HashSet<Object>();
		for (int i = 0; i < jsonArray.length(); i++) {
			Object son;
			Object obj = jsonArray.get(i);
			if (obj.getClass() == JSONObject.class) {
				son = json2Pojo((JSONObject) obj, (Class) type);
			} else if (obj.getClass() == JSONArray.class) {
				son = jsonArray2Pojo((JSONArray) obj, type);
			} else {
				son = obj;
			}
			set.add(son);
		}
		return set;
	}

	// JSON数组转换为POJO List
	public static List<Object> jsonArray2PojoList(JSONArray jsonArray, Type type)
			throws JSONException, ClassNotFoundException {
		List<Object> list = new ArrayList<Object>();
		for (int i = 0; i < jsonArray.length(); i++) {
			Object son;
			Object obj = jsonArray.get(i);
			if (obj.getClass() == JSONObject.class) {
				son = json2Pojo((JSONObject) obj, (Class) type);
			} else if (obj.getClass() == JSONArray.class) {
				son = jsonArray2Pojo((JSONArray) obj, type);
			} else {
				son = obj;
			}
			list.add(son);
		}
		return list;
	}

	// == private =========================================
	// 查找子元素的真正类型
	private static Type getGenericClass(Type t) throws ClassNotFoundException {
		if (t instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType) t;
			return pt.getActualTypeArguments()[0];
		} else {
			return Object.class;
		}
	}

	// 检查是否基本类型
	public static boolean checkBaseType(Class<?> cType) {
		return cType == Integer.class || cType == Long.class
				|| cType == Float.class || cType == Double.class
				|| cType == String.class || cType == Boolean.class;
	}

	public static <T> T Object2BaseType(Object o, Class<T> type) {
		if (checkBaseType(type)) {
			if (o == null) {
				if (type == Integer.class || type == Long.class
						|| type == Float.class || type == Double.class) {
					o = 0;
				} else if (type == Boolean.class) {
					o = false;
				} else {
					return null;
				}
				return (T) o;
			} else {
				if (type == Integer.class)
					o = Integer.parseInt(o.toString());
				else if (type == Long.class)
					o = Long.parseLong(o.toString());
				else if (type == Float.class)
					o = Float.parseFloat(o.toString());
				else if (type == Double.class)
					o = Double.parseDouble(o.toString());
				else if (type == Boolean.class)
					o = Boolean.parseBoolean(o.toString());
				else
					o = o.toString();
				return (T) o;
			}
		} else {
			return null;
		}
	}

}
