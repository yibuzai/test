package com.framework.network;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

/** 
 * TODO<Http异常> 
 * @author zqk
 * @data:  2015年8月23日 下午4:27:19 
 * @version:  V1.0 
 */
public class HttpException extends Exception {

	private static final long serialVersionUID = -2801395507989002141L;
	private int code;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public HttpException(int code, String detailMessage) {
		super(detailMessage);
		this.code = code;
	}

	public HttpException(int code, Exception e) {
		super(e);
		this.code = code;
	}

	public static HttpException http(int paramInt) {
		return new HttpException(HttpError.ERROR_STATUSCODE,
				"error http responsecode:" + paramInt);
	}

	public static HttpException http(Exception e) {
		return new HttpException(HttpError.ERROR_STATUSCODE, e);
	}

	public static HttpException io(IOException exception) {
		return new HttpException(HttpError.ERROR_IO, exception);
	}

	public static HttpException network(Exception exception) {
		if (exception instanceof UnknownHostException
				|| exception instanceof ConnectException)
			return new HttpException(HttpError.ERROR_NETWORD, exception);
		if (exception instanceof SocketException)
			return new HttpException(HttpError.ERROR_SOCKET, exception);
		if (exception instanceof SocketTimeoutException)
			return new HttpException(HttpError.ERROR_TIMEOUT, exception);

		return http(exception);
	}

	public static HttpException data(Exception exception) {
		return new HttpException(HttpError.ERROR_DATA_TRAN, exception);
	}
}
