package com.framework.base;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;

import com.zqk.test.app.FragmentActivityManager;
import com.zqk.test.ui.widget.toast.ToastBlack;
import com.zhy.autolayout.AutoLayoutActivity;

import java.lang.ref.WeakReference;
import java.util.List;

/**
 * TODO<抽象FragmentActivity，提供刷新UI的Handler>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:17:34
 * @version: V1.0
 */
public abstract class BaseFragmentActivity extends AutoLayoutActivity implements
		OnClickListener {
	private boolean isShowing;

	public Context mContext;

	private boolean background = false;

	String mPackageName;

	ActivityManager mActivityManager;

	PowerManager powerManager;

	protected Handler mUiHandler = new UiHandler(this) {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (getActivityReference() != null
					&& getActivityReference().get() != null) {
				getActivityReference().get().handleUiMessage(msg);
			}
		};
	};

	private static class UiHandler extends Handler {
		private final WeakReference<BaseFragmentActivity> mActivityReference;

		public UiHandler(BaseFragmentActivity activity) {
			mActivityReference = new WeakReference<BaseFragmentActivity>(
					activity);
		}

		public WeakReference<BaseFragmentActivity> getActivityReference() {
			return mActivityReference;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = this;
		FragmentActivityManager.getActivityManager().pushActivity(this);
		setCView();
		initView();
		initData();
	}


	public abstract void setCView();

	public abstract void initView();

	public abstract void initData();

	@Override
	protected void onDestroy() {
		super.onDestroy();
		FragmentActivityManager.getActivityManager().popActivity(this);
	}

	/**
	 * 处理更新UI任务
	 * 
	 * @param msg
	 */
	protected void handleUiMessage(Message msg) {
	}

	/**
	 * 发送UI更新操作
	 * 
	 * @param msg
	 */
	public void sendUiMessage(Message msg) {
		mUiHandler.sendMessage(msg);
	}

	protected void sendUiMessageDelayed(Message msg, long delayMillis) {
		mUiHandler.sendMessageDelayed(msg, delayMillis);
	}

	/**
	 * 发送UI更新操作
	 * 
	 * @param what
	 */
	protected void sendEmptyUiMessage(int what) {
		mUiHandler.sendEmptyMessage(what);
	}

	protected void sendEmptyUiMessageDelayed(int what, long delayMillis) {
		mUiHandler.sendEmptyMessageDelayed(what, delayMillis);
	}

	/**
	 * 显示一个Toast类型的消息
	 * 
	 * @param msg
	 *            显示的消息
	 */
	public void showToast(final String msg) {
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				ToastBlack.showText(BaseFragmentActivity.this, msg, false);
			}
		});
	}

	/**
	 * 显示通知
	 * 
	 * @param strResId
	 *            字符串资源id
	 */
	public void showToast(final int strResId) {
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				ToastBlack.showText(BaseFragmentActivity.this, getResources()
						.getString(strResId), false);
			}
		});
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		isShowing = true;
		if (background) {
			background = false;
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		isShowing = false;
		mActivityManager = ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE));
		mPackageName = getPackageName();

		powerManager = (PowerManager) this.getSystemService(this.POWER_SERVICE);

	}

	public boolean isAppOnForeground() {

		List<RunningTaskInfo> tasksInfo = mActivityManager.getRunningTasks(1);

		if (tasksInfo.size() > 0) {
			// 应用程序位于堆栈的顶层
			if (mPackageName.equals(tasksInfo.get(0).topActivity
					.getPackageName())) {
				return true;
			}
		}
		return false;

	}

	public final static boolean isScreenLocked(Context c) {
		boolean ScreenLocked = false;
		KeyguardManager mKeyguardManager = (KeyguardManager) c
				.getSystemService(c.KEYGUARD_SERVICE);
		ScreenLocked = !mKeyguardManager.inKeyguardRestrictedInputMode();
		return ScreenLocked;

	}

	public boolean isShowing() {
		return isShowing;
	}

	/**
	 * 显示软键盘
	 */
	public void showSoftInput() {
		InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		manager.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}

	/**
	 * 隐藏软键盘
	 */
	public void hideSoftInput(Context context) {
		InputMethodManager manager = (InputMethodManager) context
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		if (getCurrentFocus() != null) {
			manager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
					InputMethodManager.HIDE_NOT_ALWAYS);
		}
	}

	/**
	 * @Title: startAnimationActivity
	 * @Description: 开始动画跳转
	 * @param it
	 * @return void
	 */
	public void startAnimationActivity(Intent it) {
		startActivity(it);
		overridePendingTransition(android.R.anim.fade_in,
				android.R.anim.fade_out);
	}

	/**
	 * @Title: startAnimationActivityForResult
	 * @Description: 开始动画跳转
	 * @param it
	 * @param requestCode
	 * @return void
	 */
	public void startAnimationActivityForResult(Intent it, int requestCode) {
		startActivityForResult(it, requestCode);
		overridePendingTransition(android.R.anim.fade_in,
				android.R.anim.fade_out);
	}

	/**
	 * @Title: finishAnimationActivity
	 * @Description: 动画方式结束页面
	 * @return void
	 */
	public void finishAnimationActivity() {
		finish();
		overridePendingTransition(android.R.anim.fade_in,
				android.R.anim.fade_out);
	}
}
