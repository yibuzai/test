package com.framework.util;

import android.util.Log;

/** 
 * TODO<日志工具> 
 * @author zqk
 * @data:  2015年8月23日 下午4:21:16 
 * @version:  V1.0 
 */
public class LogUtils {

	private static final String TAG = "Log";

	private static boolean isDebug = true;

	/**
	 * 是否处于调试模式
	 * 
	 * @param debug
	 */
	public static boolean isDebug() {
		return isDebug;
	}

	public static void d(String msg) {
		if (isDebug) {
			Log.d(TAG, msg);
		}
	}

	public static void d(String tag, String msg) {
		if (isDebug) {
			Log.d(tag, msg);
		}
	}

	public static void e(String msg) {
		if (isDebug) {
			Log.e(TAG, msg);
		}
	}

	public static void e(String tag, String msg) {
		if (isDebug) {
			Log.e(tag, msg);
		}
	}

}
