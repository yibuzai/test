package com.framework.network;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.framework.network.BaseResponsePackage.ResultChecker;

/** 
 * TODO<Http 结果处理> 
 * @author zqk
 * @data:  2015年8月23日 下午4:27:32 
 * @version:  V1.0 
 */
public abstract class HttpHandler<T> extends Handler implements ResultChecker {

	/**
	 * jsonobject对应的属性类
	 */
	private Class<T> mClazz;

	/**
	 * json自动解析的key
	 */
	private String mKey;

	/**
	 * 响应包
	 */
	private BaseResponsePackage mRpg;

	/**
	 * 检查的key
	 */
	private String mCheckKey = "code";

	/**
	 * http是否响应成功，需要和后台联合设置
	 * 
	 * 1后台设置成功响应的标志字段
	 */
	private String mSuccessValue = "";

	// private String successValue = "1";

	public HttpHandler(String key, Class<T> clazz) {
		this.mKey = key;
		this.mClazz = clazz;
	}

	/**
	 * 设置检查key和标志字段
	 * 
	 * @param checkKey
	 * @param successValue
	 * @return
	 */
	public HttpHandler<T> setCheckKey(String checkKey, String successValue) {
		if (TextUtils.isEmpty(checkKey) || TextUtils.isEmpty(successValue))
			return this;
		this.mCheckKey = checkKey;
		this.mSuccessValue = successValue;
		return this;
	}

	public String getSuccessValue() {
		return mSuccessValue;
	}

	public Class<T> getClazz() {
		return mClazz;
	}

	public void setClazz(Class<T> clazz) {
		this.mClazz = clazz;
	}

	public String getKey() {
		return mKey;
	}

	public void setKey(String key) {
		this.mKey = key;
	}

	/**
	 * handler的处理消息队列的方法 在RequestResultCallbackImpl里面sendMessage
	 */
	@Override
	public void handleMessage(Message msg) {
		switch (msg.what) {
		case 0:
			Exception e = (Exception) msg.obj;
			e.printStackTrace();
			if (e instanceof HttpException)
				onFinish(null, new HttpError(((HttpException) e).getCode(), e));
			else
				onFinish(null, new HttpError(HttpError.ERROR_OTHER, e));
			break;
		case 1:
			mRpg = (BaseResponsePackage) msg.obj;
			try {
				if (mRpg.isCustomParser()) {
					onFinish((T) mRpg.getResult(), null);
				} else {
					onFinish(mRpg.getDataWithKey(mKey, mClazz), null);
				}
			} catch (HttpException e1) {
				onFinish(null, new HttpError(e1.getCode(), e1));
			}
			break;
		default:
			break;
		}
	}

	@Override
	public String getCheckKey() {
		return mCheckKey;
	}

	@Override
	public String getDataKey() {
		return mKey;
	}

	@Override
	public Class getDataClass() {
		return mClazz;
	}

	/**
	 * 检查http是否正确响应
	 */
	@Override
	public boolean check(String value) {
		if (mSuccessValue.equals(value))
			return true;
		return false;
	}

	public abstract void onFinish(T data, HttpError error);

	public BaseResponsePackage getResponseData() {
		return mRpg;
	}

}
