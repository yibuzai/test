package com.framework.network;

import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/** 
 * TODO<默认阻塞线程池
 * 线程数10
 * 最大线程数100> 
 * @author zqk
 * @data:  2015年8月23日 下午4:26:23 
 * @version:  V1.0 
 */
public class DefaultThreadPool {

	private ArrayBlockingQueue<Runnable> mBlockingQueue = new ArrayBlockingQueue<Runnable>(
			15);

	private AbstractExecutorService mPool = new ThreadPoolExecutor(10, 100,
			15L, TimeUnit.SECONDS, mBlockingQueue,
			new ThreadPoolExecutor.DiscardOldestPolicy());

	private static DefaultThreadPool sInstance = null;

	public static DefaultThreadPool getInstance() {
		if (sInstance == null) {
			sInstance = new DefaultThreadPool();
		}
		return sInstance;
	}

	public void execute(Runnable r) {
		mPool.execute(r);
	}

	public void shutdown() {
		if (mPool != null) {
			mPool.shutdown();
		}
	}

	public void shutdownRightnow() {
		if (mPool != null) {
			mPool.shutdownNow();
			try {
				mPool.awaitTermination(1, TimeUnit.MICROSECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void removeTaskFromQueue() {
		// blockingQueue.contains(o);
	}
}
