package com.framework.network;

import java.io.Serializable;
import java.util.Hashtable;

import org.apache.http.HttpEntity;

/**
 * TODO<抽象标准http请求包 封装标准的请求参数>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:25:29
 * @version: V1.0
 */
public abstract class BaseRequestPackage implements Serializable {

	private static final long serialVersionUID = -1997321982999205009L;

	/**
	 * 默认的http链接超时时间15s
	 */
	public static final int DEFAUlT_CONNECT_TIMEOUT = 15000;

	/**
	 * 默认的socket链接超时时间15s
	 */
	public static final int DEFAULT_SOCKET_TIMEOUT = 15000;

	/**
	 * http请求类型get
	 */
	public static int TYPE_GET = 0;

	/**
	 * http请求类型post
	 */
	public static int TYPE_POST = 1;

	/**
	 * 连接超时时间
	 */
	private int mConnectTimeout;

	/**
	 * socket超时时间
	 */
	private int mSocketTimeout;

	public int getConnectTimeout() {
		if (mConnectTimeout == 0)
			return DEFAUlT_CONNECT_TIMEOUT;
		return mConnectTimeout;
	}

	public BaseRequestPackage setConnectTimeout(int connectTimeout) {
		this.mConnectTimeout = connectTimeout;
		return this;
	}

	public int getSoTimeout() {
		if (mSocketTimeout == 0)
			return DEFAULT_SOCKET_TIMEOUT;
		return mSocketTimeout;
	}

	public BaseRequestPackage setSoTimeout(int soTimeout) {
		this.mSocketTimeout = soTimeout;
		return this;
	}

	public HttpEntity getPostEntity() {
		return null;
	}

	public Hashtable<String, String> getRequestHeaders() {
		Hashtable<String, String> headers = new Hashtable<String, String>();
		return headers;
	}

	public abstract Hashtable<String, Object> getRequestParams();

	public abstract String getUrl();

	public abstract int getRequsetType();
}
