package com.framework.network;

import com.framework.util.LogUtils;
import com.framework.util.ObjectTranslatorUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.Hashtable;

/**
 * TODO<标准http响应包 封装标准的响应参数 json对象解析>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:25:42
 * @version: V1.0
 */
public class BaseResponsePackage implements Serializable {

	private static final long serialVersionUID = 2728799352541694390L;

	/**
	 * 响应的原始JSON对象数据
	 */
	private JSONObject mData;

	/**
	 * 响应结果是否正常
	 */
	private boolean mIsOk;

	/**
	 * 结果检查器
	 */
	private ResultChecker mResultChecker;

	/**
	 * 是否需要加密解密
	 */
	private boolean mIsEncrypt = false;

	/**
	 * 是否需要自己处理结果字符串
	 */
	private boolean mIsCustomParser = false;

	/**
	 * 结果字段
	 */
	private String mResult = "";

	/**
	 * json解析之后的结果
	 */
	private Hashtable<String, Object> mDataMap;

	public boolean isOk() {
		return mIsOk;
	}

	public boolean isCustomParser() {
		return mIsCustomParser;
	}

	public String getResult() {
		LogUtils.e("zqkzqk", "网络请求的结果：" + mResult);
		return mResult;
	}

	public BaseResponsePackage(ResultChecker resultChecker, boolean isEncrypt) {
		this.mResultChecker = resultChecker;
		this.mIsEncrypt = isEncrypt;
		this.mIsCustomParser = false;
	}

	public BaseResponsePackage(ResultChecker resultChecker, boolean isEncrypt,
			boolean isCustomParser) {
		this.mResultChecker = resultChecker;
		this.mIsEncrypt = isEncrypt;
		this.mIsCustomParser = isCustomParser;
	}

	public void setData(byte[] data) throws HttpException {
		if (data == null || data.length == 0)
			return;
		String jsonResult = new String(data);

		if (mIsEncrypt) {
			// try {
			// jsonResult = AESUtil.decrypt(jsonResult,
			// KeyStore.getIptvKey(BaseApplication.getInstance()));
			// } catch (Exception e) {
			// e.printStackTrace();
			// }
		}

		if (mIsCustomParser) {
			this.mIsOk = true;
			mResult = jsonResult;
			return;
		}

		try {
			mData = new JSONObject(jsonResult);
			if (mResultChecker != null) {
				String flag = mData.optString(mResultChecker.getCheckKey(), "");
				this.mIsOk = mResultChecker.check(flag);
				if (this.mIsOk) {
					mDataMap = new Hashtable<String, Object>();
					mDataMap.put(
							mResultChecker.getDataKey(),
							getDataWithKey(mResultChecker.getDataKey(),
									mResultChecker.getDataClass()));
				}
			}
		} catch (JSONException e) {
			throw HttpException.data(e);
		}
	}

	public JSONObject getData() {
		if (mData == null)
			return new JSONObject();
		return mData;
	}

	public <T> T getDataWithKey(String key, Class<T> clazz)
			throws HttpException {

		/**
		 * 如果需要自定义解析的话
		 */
		if (mIsCustomParser) {
			return (T) mResult;
		}

		if (mDataMap != null && mDataMap.contains(key)) {
			return (T) mDataMap.remove(key);
		}
		T t = null;
		if (isOk() && mData != null) {
			if (clazz.equals(Void.class)) {
				return null;
			}
			try {
				t = specialPackageMsg(key, clazz);
			} catch (Exception e) {
				throw HttpException.data(e);
			}
		}
		return t;
	}

	@SuppressWarnings("unchecked")
	private <T> T specialPackageMsg(JSONObject o, String key, Class<T> clazz)
			throws JSONException, ClassNotFoundException {
		if (o == null)
			return null;
		Object jData;
		if (key == null) {
			jData = o;
		} else {
			if (key.contains(".")) {
				jData = o;
				String[] strs = key.split("\\.");
				for (String str : strs) {
					jData = ((JSONObject) jData).get(str);
				}
			} else {
				jData = o.get(key);
			}
		}
		T data;
		if (jData instanceof JSONObject) {
			if (JSONObject.class.equals(clazz)) {
				data = (T) jData;
			} else {
				data = ObjectTranslatorUtils.json2Pojo((JSONObject) jData,
						clazz);
			}
		} else if (jData instanceof JSONArray) {
			if (JSONArray.class.equals(clazz)) {
				data = (T) jData;
			} else {
				data = (T) ObjectTranslatorUtils.jsonArray2PojoArray(
						(JSONArray) jData, clazz.getComponentType());
			}
		} else {
			data = (T) jData;
		}
		return data;
	}

	private <T> T specialPackageMsg(String key, Class<T> clazz)
			throws Exception {
		return specialPackageMsg(mData, key, clazz);
	}

	public interface ResultChecker {
		public String getCheckKey();

		public String getDataKey();

		public Class getDataClass();

		public boolean check(String value);
	}
}
