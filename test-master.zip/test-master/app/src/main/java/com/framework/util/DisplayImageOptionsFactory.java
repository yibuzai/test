package com.framework.util;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.zqk.test.R;

/**
 * TODO<图片加载器的选项>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:20:29
 * @version: V1.0
 */
public class DisplayImageOptionsFactory {

	private static DisplayImageOptions sOperator;
	private static int sResId;

	/**
	 * @Title: getInstance
	 * @Description: 同步获取图片加载选项的单例
	 * @return DisplayImageOptions
	 */
	public static synchronized DisplayImageOptions getInstance() {
		return getInstance(R.mipmap.ic_default_loading);
	}

	/**
	 * @Title: getInstance
	 * @Description: 同步获取图片加载选项的单例
	 * @param resId
	 * @return DisplayImageOptions
	 */
	public static synchronized DisplayImageOptions getInstance(int resId) {
		if (sOperator == null || sResId != resId) {
			sResId = resId;
			sOperator = new DisplayImageOptions.Builder()
					.showImageOnLoading(resId).showImageForEmptyUri(resId)
					.showImageOnFail(resId).cacheInMemory(true)
					.cacheOnDisk(true).build();
		}
		return sOperator;
	}
}
