package com.framework.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.view.View;

import com.zqk.test.R;
import com.zqk.test.ui.widget.dialog.TipDialog;

/**
 * TODO<手机工具类>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:22:46
 * @version: V1.0
 */
public class PhoneUtil {

	/**
	 * @Title: getDeviceID
	 * @Description: 获取手机唯一id
	 * @param context
	 * @return String 返回类型
	 * @throws
	 */
	public static String getDeviceID(Context context) {
		return ((TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
	}

	/**
	 * 获取当前应用的版本号
	 *
	 * @param context
	 * @return
	 */
	public static int getVersionCode(Context context) {
		int versionCode = -1;
		try {
			PackageInfo info = context.getPackageManager().getPackageInfo(
					context.getPackageName(), 0);
			versionCode = info.versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return versionCode;
	}

	/**
	 * @Title: getVersionName
	 * @Description: 获取当前应用的版本号
	 * @param context
	 * @return String
	 * @throws
	 */
	public static String getVersionName(Context context) {
		String version = "";
		try {
			// 获取packagemanager的实例
			PackageManager packageManager = context.getPackageManager();
			// getPackageName()是你当前类的包名，0代表是获取版本信息
			PackageInfo packInfo = packageManager.getPackageInfo(
					context.getPackageName(), 0);
			version = packInfo.versionName;
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return version;
	}

	/**
	 * 获取手机型号
	 * 
	 * @return
	 */
	public static String getPhoneModel() {
		return Build.MODEL;
	}

	
	/**
	 * 拨打电话
	 * 
	 * @param context
	 * @param number
	 */
	public static void makePhoneCall(final Context context, final String number) {

		TipDialog mTip = new TipDialog(context, new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				switch (view.getId()){
					case R.id.dialog_btn_sure:
						Intent phoneIntent = new Intent("android.intent.action.CALL",
								Uri.parse("tel:" + number));
						if(!(context instanceof Activity)) {
							phoneIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						}
						context.startActivity(phoneIntent);
						break;
				}
			}
		});
		mTip.setMessage("确定拨打 "+number+" ?");
		mTip.show();

	}
}
