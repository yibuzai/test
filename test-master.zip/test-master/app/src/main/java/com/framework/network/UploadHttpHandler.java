package com.framework.network;

import android.os.Bundle;
import android.os.Message;

/** 
 * TODO<http 上传结果处理> 
 * @author zqk
 * @data:  2015年8月23日 下午4:29:13 
 * @version:  V1.0 
 */
public abstract class UploadHttpHandler<T> extends HttpHandler<T> {

	public UploadHttpHandler(String key, Class<T> clazz) {
		super(key, clazz);
	}

	@Override
	public void handleMessage(Message msg) {
		super.handleMessage(msg);
		switch (msg.what) {
		case 2:
			Bundle b = msg.getData();
			long current = b.getLong("current");
			long total = b.getLong("total");
			onUpload(current, total);
		default:
			break;
		}
	}

	public abstract void onUpload(long current, long total);

}
