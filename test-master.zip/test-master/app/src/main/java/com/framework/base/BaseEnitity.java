package com.framework.base;

import java.io.Serializable;

/**
 * TODO<属性基类>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:17:09
 * @version: V1.0
 */
public abstract class BaseEnitity implements Serializable {

}
