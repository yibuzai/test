package com.framework.base;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.framework.network.AsyncHttpTask;
import com.framework.network.HttpError;
import com.framework.network.HttpHandler;
import com.zqk.test.logic.business.HttpErrorHelper;
import com.zqk.test.ui.widget.dialog.LoadingDialog;

import java.lang.ref.WeakReference;
import java.util.Hashtable;

/** 
 * TODO<可处理耗时操作的fragment> 
 * @author zqk
 * @data:  2015年8月23日 下午4:18:28 
 * @version:  V1.0 
 */
public abstract class BaseWorkerFragment extends BaseFragment {

	protected HandlerThread mHandlerThread;

	protected BackgroundHandler mBackgroundHandler;
	
	protected LoadingDialog mLoadingDialog;

	private int content_layout_resource;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		//super.onCreate(savedInstanceState);

		mHandlerThread = new HandlerThread("fragment worker:"
				+ getClass().getSimpleName());
		mHandlerThread.start();
		mBackgroundHandler = new BackgroundHandler(this,
				mHandlerThread.getLooper()) {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				if (getFragmentReference() != null
						&& getFragmentReference().get() != null) {
					getFragmentReference().get().handleBackgroundMessage(msg);
				}
			}
		};
		content_layout_resource = setCView();
		View content = inflater.inflate(content_layout_resource, null);
		initView(content);
		return content;
	}

	protected abstract int setCView();
	protected abstract void initView(View view);

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		initData();
	}

	protected abstract void initData();

	@Override
	public void onStart() {
		super.onStart();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mBackgroundHandler != null
				&& mBackgroundHandler.getLooper() != null) {
			mBackgroundHandler.getLooper().quit();
		}
	}

	/**
	 * 处理后台操作
	 */
	protected void handleBackgroundMessage(Message msg) {
	}

	/**
	 * 发送后台操作
	 * 
	 * @param msg
	 */
	protected void sendBackgroundMessage(Message msg) {
		if (mBackgroundHandler != null) {
			mBackgroundHandler.sendMessage(msg);
		}
	}

	protected void sendBackgroundMessageDelayed(Message msg, long delayMillis) {
		if (mBackgroundHandler != null) {
			mBackgroundHandler.sendMessageDelayed(msg, delayMillis);
		}
	}

	/**
	 * 发送后台操作
	 * 
	 * @param what
	 */
	protected void sendEmptyBackgroundMessage(int what) {
		if (mBackgroundHandler != null) {
			mBackgroundHandler.sendEmptyMessage(what);
		}
	}

	protected void sendEmptyBackgroundMessageDelayed(int what, long delayMillis) {
		if (mBackgroundHandler != null) {
			mBackgroundHandler.sendEmptyMessageDelayed(what, delayMillis);
		}
	}

	/**
	 *  发送post请求
	 * @param activity
	 * @param url
	 * @param params
	 * @param successWhat
	 * @param faileWhat
	 */
	protected void post(final Activity activity, String url, Hashtable<String, Object> params, final int successWhat, final int faileWhat) {
		AsyncHttpTask.post(url, params,
				new HttpHandler<String>("", String.class) {
					@Override
					public void onFinish(String data, HttpError error) {

						if (HttpErrorHelper.isRequestError(data, error)) {
							// 网络请求出错
							Message msg = new Message();
							msg.what = faileWhat;
							msg.obj = HttpErrorHelper.getRequestErrorReason(activity, data, error);
							sendUiMessage(msg);
							return;
						}

						Message msg = new Message();
						msg.what = successWhat;
						msg.obj = data;
						sendUiMessage(msg);
					}
				}, false, false, true);
	}

	/**
	 *  发送get请求
	 * @param activity
	 * @param url
	 * @param params
	 * @param successWhat
	 * @param faileWhat
	 */
	protected void get(final Activity activity, String url, Hashtable<String, Object> params, final int successWhat, final int faileWhat) {
		AsyncHttpTask.get(url, params,
				new HttpHandler<String>("", String.class) {
					@Override
					public void onFinish(String data, HttpError error) {

						if (HttpErrorHelper.isRequestError(data, error)) {
							// 网络请求出错
							Message msg = new Message();
							msg.what = faileWhat;
							msg.obj = HttpErrorHelper.getRequestErrorReason(activity, data, error);
							sendUiMessage(msg);
							return;
						}

						Message msg = new Message();
						msg.what = successWhat;
						msg.obj = data;
						sendUiMessage(msg);
					}
				}, false, false, true);
	}

	/**
	 * 弹出LoadingDialog
	 * @param message
	 */
	protected void showLoadingDialog(String message){
		if (mLoadingDialog == null)
			mLoadingDialog = new LoadingDialog(getActivity());
		mLoadingDialog.setMessage(message);
		mLoadingDialog.show();
	}

	/**
	 * 关闭LoadingDialog
	 */
	protected void dismissLoadingDialog(){
		if (mLoadingDialog != null)
			mLoadingDialog.dismiss();
	}


	// 后台Handler
	private static class BackgroundHandler extends Handler {

		private final WeakReference<BaseWorkerFragment> mFragmentReference;

		BackgroundHandler(BaseWorkerFragment fragment, Looper looper) {
			super(looper);
			mFragmentReference = new WeakReference<BaseWorkerFragment>(fragment);
		}

		public WeakReference<BaseWorkerFragment> getFragmentReference() {
			return mFragmentReference;
		}

	}

}
