package com.framework.base;

import java.util.Hashtable;

import android.app.Application;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Handler;
import android.widget.Toast;

/**
 * TODO<应用程序基类>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:16:45
 * @version: V1.0
 */
public abstract class BaseApplication extends Application {

	private static BaseApplication sApplication;

	// 应用全局变量存储在这里
	private static Hashtable<String, Object> mAppParamsHolder;

	private static final int MSG_SHOW_MSG = 0X01;

	private static Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MSG_SHOW_MSG:
				Toast.makeText(sApplication, (String) msg.obj,
						Toast.LENGTH_SHORT).show();
				break;
			}
		};
	};

	@Override
	public void onCreate() {
		super.onCreate();
		sApplication = this;
		mAppParamsHolder = new Hashtable<String, Object>();
	}

	/**
	 * 获取Application实例
	 * 
	 * @return
	 */
	public static BaseApplication getInstance() {
		if (sApplication == null) {
			throw new IllegalStateException("Application is not created.");
		}
		return sApplication;
	}

	/**
	 * 存储全局数据
	 * 
	 * @param key
	 * @param value
	 */
	public static void putValue(String key, Object value) {
		mAppParamsHolder.put(key, value);
	}

	/**
	 * 获取全局数据
	 * 
	 * @param key
	 * @return
	 */
	public static Object getValue(String key) {
		return mAppParamsHolder.get(key);
	}

	/**
	 * 是否已存放
	 * 
	 * @param key
	 * @return
	 */
	public static boolean containsKey(String key) {
		return mAppParamsHolder.containsKey(key);
	}

	/**
	 * 获取自身App安装包信息
	 * 
	 * @return
	 */
	public PackageInfo getLocalPackageInfo() {
		return getPackageInfo(getPackageName());
	}

	/**
	 * 获取App安装包信息
	 * 
	 * @return
	 */
	public PackageInfo getPackageInfo(String packageName) {
		PackageInfo info = null;
		try {
			info = getPackageManager().getPackageInfo(packageName, 0);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return info;
	}

	/**
	 * 显示提示信息
	 * 
	 * @param msg
	 */
	public static void showToast(String msg) {
		mHandler.obtainMessage(MSG_SHOW_MSG, msg).sendToTarget();
	}

}
