package com.framework.network;

import java.util.Hashtable;

/**
 * TODO<http Task 1包含多种post和get请求 2封装了http请求包，http handle和请求结果回调>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:25:14
 * @version: V1.0
 */
public class AsyncHttpTask implements Runnable {

	/**
	 * http结果handler
	 */
	private HttpHandler mHttpHandler;

	/**
	 * 请求参数包
	 */
	private BaseRequestPackage mRequest;

	/**
	 * http请求回调
	 */
	private RequestResultCallback mRequestCallback;

	/**
	 * 是否重试
	 * 
	 * http链接出错的时候重试3次
	 */
	private boolean mIsRetry;

	/**
	 * 是否需要aes加密和解密
	 * 
	 * 请求时对参数加密 返回时对结果字符串解密
	 */
	private boolean mIsEncrypt;

	/**
	 * 是否需要自己处理结果字符串
	 */
	private boolean mIsCustomParser = false;

	/**
	 * post http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 */
	public static void post(String url, Hashtable<String, Object> params,
			HttpHandler handler) {
		post(url, params, handler, BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT, false, false, false);
	}

	/**
	 * post http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param isEncrypt
	 *            是否加密解密
	 */
	public static void post(String url, Hashtable<String, Object> params,
			HttpHandler handler, boolean isEncrypt, boolean isCustomParser) {
		post(url, params, handler, BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT, false, isEncrypt,
				isCustomParser);
	}

	/**
	 * post http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param isRetry
	 *            超时重连
	 * @param isEncrypt
	 *            是否加密解密
	 */
	public static void post(String url, Hashtable<String, Object> params,
			HttpHandler handler, boolean isRetry, boolean isEncrypt,
			boolean isCustomParser) {
		post(url, params, handler, BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT, isRetry, isEncrypt,
				isCustomParser);
	}

	/**
	 * post http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param connectTimeout
	 *            http连接超时时间
	 * @param soTimeout
	 *            socket连接超时时间
	 */
	public static void post(String url, Hashtable<String, Object> params,
			HttpHandler handler, int connectTimeout, int soTimeout) {
		post(url, params, handler, connectTimeout, soTimeout, true, false,
				false);
	}

	/**
	 * post http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param connectTimeout
	 *            http连接超时时间
	 * @param soTimeout
	 *            socket连接超时时间
	 * @param isRetry
	 *            是否重试，在http请求失败的时候
	 * @param isEncrypt
	 *            是否加密解密
	 */
	public static void post(String url, Hashtable<String, Object> params,
			HttpHandler handler, int connectTimeout, int soTimeout,
			boolean isRetry, boolean isEncrypt, boolean mIsCustomParser) {
		AsyncHttpTask p = new AsyncHttpTask(handler, url, params,
				BaseRequestPackage.TYPE_POST, connectTimeout, soTimeout,
				isRetry, isEncrypt, mIsCustomParser);
		DefaultThreadPool.getInstance().execute(p);
	}

	/**
	 * get http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 */
	public static void get(String url, Hashtable<String, Object> params,
			HttpHandler handler) {
		get(url, params, handler, BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT);
	}

	/**
	 * get http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param isRetry
	 *            http连接出错时是否重试
	 */
	public static void get(String url, Hashtable<String, Object> params,
			HttpHandler handler, boolean isRetry) {
		get(url, params, handler, BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT, isRetry, false,
				false);
	}

	/**
	 * get http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param isRetry
	 *            http连接出错时是否重试
	 */
	public static void get(String url, Hashtable<String, Object> params,
			HttpHandler handler, boolean isRetry, boolean isEncrypt,
			boolean mIsCustomParser) {
		get(url, params, handler, BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT, isRetry, isEncrypt,
				mIsCustomParser);
	}

	/**
	 * get http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param connectTimeout
	 *            http链接超时时间
	 * @param soTimeout
	 *            socket链接超时时间
	 */
	public static void get(String url, Hashtable<String, Object> params,
			HttpHandler handler, int connectTimeout, int soTimeout) {
		get(url, params, handler, connectTimeout, soTimeout, true, false, false);
	}

	/**
	 * get http请求
	 * 
	 * @param url
	 *            请求地址
	 * @param params
	 *            请求参数
	 * @param handler
	 *            http结果处理handler
	 * @param connectTimeout
	 *            http链接超时时间
	 * @param soTimeout
	 *            socket链接超时时间
	 * @param isRetry
	 *            http连接错误时是否尝试重新连接
	 */
	public static void get(String url, Hashtable<String, Object> params,
			HttpHandler handler, int connectTimeout, int soTimeout,
			boolean isRetry, boolean isEncrypt, boolean mIsCustomParser) {
		AsyncHttpTask p = new AsyncHttpTask(handler, url, params,
				BaseRequestPackage.TYPE_GET, connectTimeout, soTimeout,
				isRetry, isEncrypt, mIsCustomParser);
		DefaultThreadPool.getInstance().execute(p);
	}

	public static void execute(BaseRequestPackage rpg, HttpHandler handler) {
		execute(rpg, handler, true);
	}

	public static void execute(BaseRequestPackage rpg, HttpHandler handler,
			boolean isRetry) {
		AsyncHttpTask p = new AsyncHttpTask(handler, rpg, isRetry, false, false);
		DefaultThreadPool.getInstance().execute(p);
	}

	public AsyncHttpTask(HttpHandler httpHandler, final String url,
			final Hashtable<String, Object> params, final int method,
			int connectTimeout, int soTimeout, boolean isRetry,
			boolean isEncrypt, boolean isCustomParser) {
		this(httpHandler, new BaseRequestPackage() {
			@Override
			public String getUrl() {
				return url;
			}

			@Override
			public int getRequsetType() {
				return method;
			}

			@Override
			public Hashtable<String, Object> getRequestParams() {
				return params;
			}
		}.setConnectTimeout(connectTimeout).setSoTimeout(soTimeout), isRetry,
				isEncrypt, isCustomParser);
	}

	public AsyncHttpTask(HttpHandler httpHandler, BaseRequestPackage rpg,
			boolean isRetry, boolean isEncrypt, boolean isCustomParser) {
		this.mHttpHandler = httpHandler;
		this.mRequestCallback = new RequestResultCallbackImpl();
		this.mRequest = rpg;
		this.mIsRetry = isRetry;
		this.mIsEncrypt = isEncrypt;
		this.mIsCustomParser = isCustomParser;
	}

	@Override
	public void run() {
		BaseResponsePackage response = new BaseResponsePackage(mHttpHandler,
				mIsEncrypt, mIsCustomParser);
		try {
			HttpClientHelper.request(mRequest, response, mIsRetry, mIsEncrypt);
			if (mHttpHandler != null && response.isOk()) {
				mRequestCallback.onSuccess(mHttpHandler, response);
			} else if (mHttpHandler != null) {
				mRequestCallback
						.onFail(mHttpHandler, new Exception(
								"result check fail : "
										+ response.getData().toString()));
			}
		} catch (Exception e) {
			mRequestCallback.onFail(mHttpHandler, e);
		}
	}
}
