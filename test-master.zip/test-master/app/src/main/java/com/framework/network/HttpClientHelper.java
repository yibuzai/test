package com.framework.network;

import com.framework.base.BaseApplication;
import com.framework.util.LogUtils;
import com.framework.util.NetStatusCheckUtil;
import com.framework.util.UrlEncodeUtil;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

/**
 * TODO<httpClient工具 获取单例HttpClient对象 http request方法>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:26:38
 * @version: V1.0
 */
public class HttpClientHelper {

	private static HttpClient getHttpClient() {
		return getHttpClient(BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT);
	}

	private static HttpClient getHttpClient(int connectionTimeout, int soTimeout) {
		HttpParams params = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(params, connectionTimeout);
		HttpConnectionParams.setSoTimeout(params, soTimeout);

		DefaultHttpClient httpClient = new DefaultHttpClient(params);
		return httpClient;
	}

	private static HttpClient getHttpClient(BaseRequestPackage request) {
		if (request.getConnectTimeout() == 0 && request.getSoTimeout() == 0) {
			return getHttpClient();
		} else {
			return getHttpClient(request.getConnectTimeout(),
					request.getSoTimeout());
		}
	}

	public static void request(BaseRequestPackage pkg,
			BaseResponsePackage response, boolean isRetry, boolean isEncrypt)
			throws HttpException {
		if (!NetStatusCheckUtil.isNetworkStatus(BaseApplication.getInstance())) {
			throw HttpException.network(new Exception("error network status"));
		}
		int i = 0;
		do {
			HttpClient httpClient = null;
			try {
				httpClient = getHttpClient(pkg);
				byte[] result = null;
				if (pkg.getRequsetType() == BaseRequestPackage.TYPE_GET) {
					result = getRequest(httpClient, pkg);
				} else {
					result = postRequest(httpClient, pkg, isEncrypt);
				}
				response.setData(result);

				isRetry = false;
			} catch (HttpException e) {
				if (e.getCode() == HttpError.ERROR_NETWORD
						|| e.getCode() == HttpError.ERROR_SOCKET
						|| e.getCode() == HttpError.ERROR_TIMEOUT) {
					i++;
					e.printStackTrace();
					System.out.println("try again...");
				}
			} catch (IOException e) {
				throw HttpException.io(e);
			} finally {
				if (httpClient != null)
					httpClient.getConnectionManager().shutdown();
				httpClient = null;
			}
		} while (isRetry && i < 3);
	}

	private static byte[] getResult(HttpResponse response) throws IOException,
			HttpException {
		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode == HttpStatus.SC_OK) {
			ByteArrayOutputStream content = new ByteArrayOutputStream();
			response.getEntity().writeTo(content);
			byte[] result = content.toByteArray();
			content.close();
			return result;
		} else {
			throw HttpException.http(statusCode);
		}
	}

	private static byte[] postRequest(HttpClient httpClient,
			BaseRequestPackage pkg) throws IOException, HttpException {
		HttpPost post = new HttpPost(pkg.getUrl());
		post.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,
				pkg.getConnectTimeout());
		post.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				pkg.getSoTimeout());
		if (pkg.getPostEntity() == null) {
			List<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
			Hashtable<String, Object> parameter = pkg.getRequestParams();
			for (String key : parameter.keySet()) {
				list.add(new BasicNameValuePair(key, parameter.get(key)
						.toString()));
			}
			post.setEntity(new UrlEncodedFormEntity(list, HTTP.UTF_8));
		} else {
			post.setEntity(pkg.getPostEntity());
		}
		initUriRequest(post, pkg);
		HttpResponse response;
		try {
			response = httpClient.execute(post);
		} catch (Exception e) {
			throw HttpException.network(e);
		}
		return getResult(response);
	}

	private static byte[] postRequest(HttpClient httpClient,
			BaseRequestPackage pkg, boolean isEncrypt) throws IOException,
			HttpException {

		StringBuilder temp = new StringBuilder();
		temp.append("httppost请求参数：地址头：" + pkg.getUrl() + ";\n");

		HttpPost post = new HttpPost(pkg.getUrl());
		post.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,
				BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT);
		post.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT);

		if (pkg.getPostEntity() == null) {
			List<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
			Hashtable<String, Object> parameter = pkg.getRequestParams();
			for (String key : parameter.keySet()) {
				list.add(new BasicNameValuePair(key, parameter.get(key)
						.toString()));

				temp.append("参数：key=" + key + ";value="
						+ parameter.get(key).toString() + ";\n");
			}
			post.setEntity(new UrlEncodedFormEntity(list, HTTP.UTF_8));
		} else {
			post.setEntity(pkg.getPostEntity());
		}

		LogUtils.e("zqkzqk", "httppost请求参数=" + temp.toString());

		initUriRequest(post, pkg);

		HttpResponse response;
		try {
			response = httpClient.execute(post);
		} catch (Exception e) {
			throw HttpException.network(e);
		}
		return getResult(response);
	}

	private static void initUriRequest(HttpUriRequest request,
			BaseRequestPackage pkg) {
		Hashtable hashtable = pkg.getRequestHeaders();
		if ((hashtable != null) && (hashtable.size() > 0)) {
			Iterator localIterator = hashtable.keySet().iterator();
			while (localIterator.hasNext()) {
				String str = (String) localIterator.next();
				if ((!"Connection".equalsIgnoreCase(str))
						&& (!"User-Agent".equalsIgnoreCase(str))) {
					request.setHeader(str, hashtable.get(str).toString());
				}
			}
		}
		request.setHeader("Connection", "Keep-Alive");

		request.getParams().setParameter(
				CoreConnectionPNames.CONNECTION_TIMEOUT,
				BaseRequestPackage.DEFAUlT_CONNECT_TIMEOUT);
		request.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				BaseRequestPackage.DEFAULT_SOCKET_TIMEOUT);
	}

	private static byte[] getRequest(HttpClient httpClient,
			BaseRequestPackage pkg) throws HttpException, IOException {
		String url = pkg.getUrl();
		Hashtable<String, Object> parameter = pkg.getRequestParams();
		if (parameter != null && parameter.size() > 0) {
			StringBuilder bulider = new StringBuilder();
			for (String key : parameter.keySet()) {
				if (bulider.length() != 0) {
					bulider.append("&");
				}
				bulider.append(UrlEncodeUtil.encode(key));
				bulider.append("=");
				bulider.append(UrlEncodeUtil.encode(parameter.get(key)
						.toString()));
			}
			url += "&" + bulider.toString();
		}

		LogUtils.e("zqkzqk", "httpget请求参数=" + url);

		HttpGet request = new HttpGet(url);
		initUriRequest(request, pkg);
		HttpResponse response;
		try {
			response = httpClient.execute(request);
		} catch (Exception e) {
			throw HttpException.network(e);
		}

		return getResult(response);
	}
}
