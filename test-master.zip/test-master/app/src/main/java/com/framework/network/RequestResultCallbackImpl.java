package com.framework.network;

import android.os.Message;

/** 
 * TODO<http 请求结果回调实现
 * onSuccess 请求成功的回调
 * onFail 请求失败的回调> 
 * @author zqk
 * @data:  2015年8月23日 下午4:28:51 
 * @version:  V1.0 
 */
public class RequestResultCallbackImpl implements RequestResultCallback {

	/**
	 * 加载成功
	 * 
	 * @param httpHandler
	 *            结果处理handler
	 * @param o
	 *            结果响应包
	 */
	@Override
	public void onSuccess(HttpHandler httpHandler, Object o) {
		if (httpHandler == null)
			return;
		// 把结果响应包发送到结果处理handler
		Message msgMessage = httpHandler.obtainMessage(1, o);
		httpHandler.sendMessage(msgMessage);
	}

	/**
	 * 加载失败
	 * 
	 * @param httpHandler
	 *            结果处理handler
	 * @param e
	 *            异常
	 */
	@Override
	public void onFail(HttpHandler httpHandler, Exception e) {
		if (httpHandler == null)
			return;
		// 把结果异常发送到结果处理handler
		Message msgMessage = httpHandler.obtainMessage(0, e);
		httpHandler.sendMessage(msgMessage);
	}

}
