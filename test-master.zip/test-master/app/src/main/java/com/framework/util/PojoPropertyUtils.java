package com.framework.util;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.HashMap;

import org.json.JSONObject;

/** 
 * TODO<android对java.beans.Introspector支持不足，原因待了解，因此实现该类对POJO类的属性进行一些操作> 
 * @author zqk
 * @data:  2015年8月23日 下午4:23:34 
 * @version:  V1.0 
 */
public class PojoPropertyUtils {
	/**
	 * 设置某个属性的值
	 * 
	 * @param pojo
	 * @param key
	 * @param value
	 */
	static public void setProperty(Object pojo, String key, Object value) {
		try {
			if (pojo.getClass() == HashMap.class) {
				((HashMap) pojo).put(key, value);
			} else if (pojo.getClass() == JSONObject.class) {
				((JSONObject) pojo).put(key, value);
			} else {
				String name = joinSetName(key);
				Method[] ms = pojo.getClass().getMethods();
				Method method = null;
				for (Method m : ms) {
					if (m.getName().equals(name)) {
						method = m;
						break;
					}
				}
				// 特殊处理
				if (method.getParameterTypes()[0].equals(Date.class)) {
					if (!(value instanceof Date)) {
						value = new Date(((Number) value).longValue());
					}
				}
				method.invoke(pojo, new Object[] { value });
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 获取某个属性的类型Class
	 * 
	 * @param pojo
	 * @param key
	 * @return
	 */
	static public Class getPropertyClass(Object pojo, String key) {
		String name = joinGetName(key);
		Method method;
		try {
			method = pojo.getClass().getMethod(name, new Class[] {});
		} catch (NoSuchMethodException e) {
			name = joinIsName(key);
			try {
				method = pojo.getClass().getMethod(name, new Class[] {});
			} catch (NoSuchMethodException e1) {
				return null;
			}
		}
		return method.getReturnType();
	}

	/**
	 * 获取某个属性的范型类型Type
	 * 
	 * @param pojo
	 * @param key
	 * @return
	 */
	static public Type getPropertyType(Object pojo, String key) {
		try {
			String name = joinGetName(key);
			Method method = pojo.getClass().getMethod(name, new Class[] {});
			return method.getGenericReturnType();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 复制属性
	 * 
	 * @param dest
	 *            目标对象（值发生变化）
	 * @param ori
	 *            源对象
	 */
	public static void copyProperties(Object dest, Object ori) {
		Method[] setMethods = setsMethodFilter(dest.getClass().getMethods());
		for (Method setMethod : setMethods) {
			String methodName = set2get(setMethod.getName());
			try {
				Method getMethod = ori.getClass().getMethod(methodName,
						new Class<?>[0]);
				Object value = getMethod.invoke(ori, new Object[0]);
				setMethod.invoke(dest, value);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 返回所有属性值（包括空值）
	 * 
	 * @param pojo
	 * @return
	 */
	public static HashMap<String, Object> getPropertysWithNull(Object pojo) {
		return getPropertys(pojo, true);
	}

	/**
	 * 返回所有属性值（不包括空值）
	 * 
	 * @param pojo
	 * @return
	 */
	public static HashMap<String, Object> getPropertysNoNull(Object pojo) {
		return getPropertys(pojo, false);
	}

	// -------------------------------------------

	private static Method[] setsMethodFilter(Method[] methods) {
		String prefix = "set";

		Method[] temps = new Method[methods.length];
		int i = 0;
		for (Method m : methods) {
			if (m.getName().startsWith(prefix)
					&& m.getName().length() > prefix.length()) {
				char c = m.getName().charAt(prefix.length());
				if (c > 64 && c < 91 || c == 95) {// A~Z and '_'
					if (!"getClass".equals(m.getName())) {
						temps[i] = m;
						i++;
					}
				}
			}
		}
		Method[] result = new Method[i];
		System.arraycopy(temps, 0, result, 0, i);
		return result;

	}

	private static Method[] getsMethodFilter(Method[] methods) {

		Method[] temps = new Method[methods.length];
		int i = 0;
		for (Method m : methods) {
			if (m.getName().startsWith("get") && m.getName().length() > 3) {
				char c = m.getName().charAt(3);
				if (c > 64 && c < 91 || c == 95) {// A~Z and '_'
					if (!"getClass".equals(m.getName())) {
						temps[i] = m;
						i++;
					}
				}
			} else if (m.getName().startsWith("is") && m.getName().length() > 2) {
				char c = m.getName().charAt(2);
				if (c > 64 && c < 91 || c == 95) {// A~Z and '_'
					if (!"getClass".equals(m.getName())) {
						temps[i] = m;
						i++;
					}
				}
			}
		}
		Method[] result = new Method[i];
		System.arraycopy(temps, 0, result, 0, i);
		return result;
	}

	private static HashMap<String, Object> getPropertys(Object pojo,
			boolean returnNullProperty) {
		if (pojo == null) {
			throw new IllegalArgumentException();
		}
		try {
			HashMap<String, Object> hm = new HashMap<String, Object>();
			Method[] ms = getsMethodFilter(pojo.getClass().getMethods());
			for (Method m : ms) {
				Object value = m.invoke(pojo, new Object[0]);
				if (value == null && !returnNullProperty) {
					continue;
				} else {
					String key = propertyName(m.getName());
					hm.put(key, value);
				}
			}
			return hm;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static String propertyName(String name) {
		int length = 3;
		if (name.indexOf("is") == 0) {
			length = 2;
		}
		String first = name.substring(length, length + 1).toLowerCase();
		String last = "";
		if (name.length() > length + 1) {
			last = name.substring(length + 1);
		}
		return first + last;
	}

	private static String set2get(String setMethodName) {
		return "g" + setMethodName.substring(1);
	}

	// private static Method[] methodFilter(Method[] methods, String prefix) {
	// Method[] temps = new Method[methods.length];
	// int i = 0;
	// for (Method m : methods) {
	// if (m.getName().startsWith(prefix) && m.getName().length() >
	// prefix.length()) {
	// char c = m.getName().charAt(prefix.length());
	// if (c > 64 && c < 91 || c == 95) {// A~Z and '_'
	// if (!"getClass".equals(m.getName())) {
	// temps[i] = m;
	// i++;
	// }
	// }
	// }
	// }
	// Method[] result = new Method[i];
	// System.arraycopy(temps, 0, result, 0, i);
	// return result;
	// }

	private static String joinGetName(String key) {
		String first = key.substring(0, 1).toUpperCase();
		return "get" + first + key.substring(1);
	}

	private static String joinIsName(String key) {
		String first = key.substring(0, 1).toUpperCase();
		return "is" + first + key.substring(1);
	}

	private static String joinSetName(String key) {
		String first = key.substring(0, 1).toUpperCase();
		return "set" + first + key.substring(1);
	}
}
