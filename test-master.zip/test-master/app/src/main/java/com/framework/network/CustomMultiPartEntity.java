package com.framework.network;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;

import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;

/** 
 * TODO<stream write进度监听> 
 * @author zqk
 * @data:  2015年8月23日 下午4:26:09 
 * @version:  V1.0 
 */
public class CustomMultiPartEntity extends MultipartEntity {

	private ProgressListener mListener;

	public CustomMultiPartEntity(ProgressListener listener) {
		super();
		this.mListener = listener;
	}

	public CustomMultiPartEntity(HttpMultipartMode mode,
			ProgressListener listener) {
		super(mode);
		this.mListener = listener;
	}

	public CustomMultiPartEntity(HttpMultipartMode mode, String boundary,
			Charset charset, ProgressListener listener) {
		super(mode, boundary, charset);
		this.mListener = listener;
	}

	@Override
	public void writeTo(OutputStream outstream) throws IOException {
		super.writeTo(new CountingOutputStream(outstream, this.mListener));
	}

	public static class CountingOutputStream extends FilterOutputStream {

		private ProgressListener listener;
		private long transferred;

		public CountingOutputStream(OutputStream out, ProgressListener listener) {
			super(out);
			this.listener = listener;
			this.transferred = 0;
		}

		public void write(byte[] b, int off, int len) throws IOException {
			out.write(b, off, len);
			this.transferred += len;
			this.listener.transferred(this.transferred);
		}

		public void write(int b) throws IOException {
			out.write(b);
			this.transferred++;
			this.listener.transferred(this.transferred);
		}
	}

	public static interface ProgressListener {
		public void transferred(long num);
	}

}
