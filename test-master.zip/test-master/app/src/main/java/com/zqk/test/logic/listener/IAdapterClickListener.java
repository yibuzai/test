package com.zqk.test.logic.listener;

/** 
 * TODO<适配器中的点击监听器> 
 * @author zqk
 * @data:  2015年8月23日 下午4:36:26 
 * @version:  V1.0 
 */
public interface IAdapterClickListener {

	// *************************************************************************
	/**
	 * 【】(适配器里的点击事件)
	 * 
	 * @param id
	 * @param position
	 */
	// *************************************************************************
	public void adapterClick(int id, int position);

}
