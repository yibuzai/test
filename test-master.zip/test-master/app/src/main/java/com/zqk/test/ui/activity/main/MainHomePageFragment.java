package com.zqk.test.ui.activity.main;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.framework.base.BaseWorkerFragment;
import com.zqk.test.R;
import com.zqk.test.logic.listener.IMainPageChangeObserver;

/**
 * TODO<首页>
 *
 * @author zqk
 * @data: 2016年03月11日 下午11:20:40
 * @version: V1.0
 */
public class MainHomePageFragment extends BaseWorkerFragment implements View.OnClickListener, IMainPageChangeObserver {

    private Button bt;
    private TextView tv_title;

    @Override
    protected int setCView() {
        return R.layout.fragment_main_home_page;
    }

    @Override
    protected void initView(View view) {
        bt = (Button) view.findViewById(R.id.bt);
        tv_title = (TextView) view.findViewById(R.id.tv_title);
        bt.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        tv_title.setText("首页");
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
            case R.id.bt:

                break;
        }
    }

    @Override
    public void onMainPageChange(Context context, int index) {

    }

}
