package com.zqk.test.ui.base;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.framework.util.DisplayImageOptionsFactory;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.zqk.test.R;
import com.zhy.autolayout.utils.AutoUtils;

/**
 * TODO<通用的ViewHolder类>
 *
 * @author zqk
 * @data: 2015年8月24日 下午2:15:44
 * @version: V1.0
 */

public class ViewHolder {
    private final SparseArray<View> mViews;
    private int mPosition;
    private View mConvertView;
    private ImageLoader mImageLoader;
    private DisplayImageOptions mDisplayImageOptions;

    private ViewHolder(Context context, ViewGroup parent, int layoutId,
                       int position) {
        this.mPosition = position;
        this.mViews = new SparseArray<View>();
        this.mImageLoader = ImageLoader.getInstance();
        this.mDisplayImageOptions = DisplayImageOptionsFactory.getInstance(R.mipmap.ic_default_loading);
        mConvertView = LayoutInflater.from(context).inflate(layoutId, parent,
                false);
        mConvertView.setTag(this);
        AutoUtils.autoSize(mConvertView);
    }

    private ViewHolder(Context context, ViewGroup parent, View view, int position) {
        this.mPosition = position;
        this.mViews = new SparseArray<View>();
        mConvertView = view;
        mConvertView.setTag(this);
        AutoUtils.autoSize(mConvertView);
    }

    /**
     * 获取ViewHolder实例化
     *
     * @param context
     * @param convertView
     * @param parent
     * @param layoutId
     * @param position
     * @return
     */
    public static ViewHolder get(Context context, View convertView, ViewGroup parent, int layoutId, int position) {
        if (convertView == null) {
            return new ViewHolder(context, parent, layoutId, position);
        }
        return (ViewHolder) convertView.getTag();
    }

    public static ViewHolder get(Context context, View mConvertView, ViewGroup parent, View view, int position) {
        if (mConvertView == null) {
            return new ViewHolder(context, parent, view, position);
        }

        return (ViewHolder) mConvertView.getTag();
    }

    public View getConvertView() {
        return mConvertView;
    }

    public int getPosition() {
        return mPosition;
    }

    /**
     * 通过viewId获取控件
     *
     * @param viewId
     * @param <T>
     * @return
     */
    public <T extends View> T getView(int viewId) {
        View view = mViews.get(viewId);
        /**
         * 判断是否存储过
         */
        if (view == null) {
            view = mConvertView.findViewById(viewId);
            mViews.put(viewId, view);
        }

        return (T) view;
    }

    /**
     * 设置TextView的值
     *
     * @param viewId
     * @param text
     * @return
     */
    public ViewHolder setText(int viewId, String text) {
        TextView view = getView(viewId);
        view.setText(text);
        return this;
    }

    public ViewHolder setText(int viewId, SpannableString text) {
        TextView view = getView(viewId);
        view.setText(text);
        return this;
    }

    public ViewHolder setText(int viewId, SpannableStringBuilder text) {
        TextView view = getView(viewId);
        view.setText(text);
        return this;
    }

    /**
     * 设置远程图像链接
     * @param viewId
     * @param url
     * @return
     */

    public ViewHolder setImageByUrl(int viewId, String url) {
//        DisplayImageOptions options = new DisplayImageOptions.Builder()
//                .cacheInMemory(true) // 启用内存缓存
//                .cacheOnDisk(true) // 启用外存缓存
//                .considerExifParams(true) // 启用EXIF和JPEG图像格式
//                .displayer(new RoundedBitmapDisplayer(10)) // 设置显示风格这里是圆角矩形
//                .build();

        ImageView imageView = getView(viewId);
//        ImageLoader.getInstance().displayImage(url, imageView, options);
        mImageLoader.displayImage(url, imageView, mDisplayImageOptions);
        return this;

    }

    /**
     * ImageView设置图片
     *
     * @param viewId
     * @param drawableId
     * @return
     */
    public ViewHolder setImageResource(int viewId, int drawableId) {
        ImageView view = getView(viewId);
        view.setImageResource(drawableId);
        return this;
    }

    /**
     * ImageView设置图片
     *
     * @param viewId
     * @param bm
     * @return
     */
    public ViewHolder setImageBitmap(int viewId, Bitmap bm) {
        ImageView view = getView(viewId);
        view.setImageBitmap(bm);
        return this;
    }
}
