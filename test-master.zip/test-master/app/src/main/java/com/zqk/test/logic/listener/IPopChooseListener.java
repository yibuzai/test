package com.zqk.test.logic.listener;

/**
 * TODO<筛选的筛选结果监听器接口>
 * 
 * @author zqk
 * @data: 2015年11月26日 下午5:48:32
 * @version: V1.0
 */
public interface IPopChooseListener {

	/**
	 * @Title: getResult
	 * @Description: 获取popwindow的结果
	 * @param postion
	 * @param result
	 */
	public void getPopChooseResult(int postion, Object result);

}
