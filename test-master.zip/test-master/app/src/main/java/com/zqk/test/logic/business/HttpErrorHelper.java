package com.zqk.test.logic.business;

import android.app.Activity;
import android.content.Context;

import com.framework.network.HttpError;
import com.framework.util.StringUtil;
import com.zqk.test.R;
import com.zqk.test.app.ZbApplication;

import org.json.JSONObject;

/** 
 * TODO<判断http请求是否出错的逻辑类> 
 * @author zqk
 * @data:  2015年8月23日 下午4:33:25 
 * @version:  V1.0 
 */
public class HttpErrorHelper {

	// *************************************************************************
	/**
	 * (接口请求是否出错)
	 * 
	 * @param data
	 * @param error
	 * @return
	 */
	// *************************************************************************
	public static boolean isRequestError(String data, HttpError error) {

		if (error != null)
			return true;

		if (StringUtil.isEmpty(data))
			return true;

		boolean isError = false;

		try {
			JSONObject json = new JSONObject(data);
			if (json != null) {
				String status = json.getString("code");
				if (!status.equals("1")) {
					isError = true;
				}
			}
		} catch (Exception e) {
			isError = true;
			e.printStackTrace();
		}

		return isError;
	}

	// *************************************************************************
	/**
	 * (获取请求错误的原因)
	 * 
	 * @param data
	 * @return
	 */
	// *************************************************************************
	public static String getRequestErrorReason(Activity activity, String data,
			HttpError error) {

		Context context = ZbApplication.getInstance();

		String errorReason = context.getString(R.string.common_text_error_net);
		if (error != null)
			return errorReason;

		if (StringUtil.isEmpty(data))
			return errorReason;

		try {
			JSONObject json = new JSONObject(data);
			if (json != null) {
				int status = json.getInt("code");
				switch (status) {
				case 400:
				case 403:
				case 404:
					/**
					 * 客户端出错
					 */
					errorReason = context
							.getString(R.string.common_text_client_error);
					break;
				case 500:
				case 503:
					/**
					 * 服务端出错
					 */
					errorReason = context
							.getString(R.string.common_text_server_error);
					break;
				default:
					errorReason = json.getString("message");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return errorReason;
	}
}
