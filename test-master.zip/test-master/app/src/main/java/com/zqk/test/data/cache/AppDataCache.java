package com.zqk.test.data.cache;

import com.zqk.test.app.ZbApplication;

import android.content.Context;

/** 
 * TODO<应用程序数据缓存> 
 * @author zqk
 * @data:  2015年8月23日 下午4:31:39 
 * @version:  V1.0 
 */
public class AppDataCache extends BaseDataCache {

	private static AppDataCache sDataCache;
	private final static String CACHE_NAME = "AppDataCache";

	public final static String IS_FIRST_WELCOME = "is_first_welcome";// 首次展示欢迎页面
	public final static String USER_ID = "user_id";// 用户id

	public static synchronized AppDataCache getInstance() {
		if (sDataCache == null) {
			Context context = ZbApplication.getInstance();
			if (context == null) {
				throw new IllegalArgumentException("context is null!");
			}
			sDataCache = new AppDataCache(context, CACHE_NAME);
		}
		return sDataCache;
	}

	/**
	 * @param appContext
	 */
	public AppDataCache(Context appContext) {
		super(appContext);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param appContext
	 * @param cacheName
	 */
	public AppDataCache(Context appContext, String cacheName) {
		super(appContext, cacheName);
		// TODO Auto-generated constructor stub
	}

	// *************************************************************************
	/**
	 * 设置是否首次进入欢迎页面
	 * 
	 * @return
	 */
	// *************************************************************************
	public void setIsFirstWelcome(boolean isFirstWelcome) {
		super.putBoolean(IS_FIRST_WELCOME, isFirstWelcome);
	}

	// *************************************************************************
	/**
	 * 获取是否首次进入欢迎页面
	 * 
	 * @return
	 */
	// *************************************************************************
	public boolean getIsFirstWelcome() {
		return super.getBoolean(IS_FIRST_WELCOME);
	}

	/**
	 * @Title: setUserId
	 * @Description:保存userid
	 * @param userId
	 */
	public void setUserId(String userId) {
		super.putString(USER_ID, userId);
	}

	/**
	 * @Title: getUserId
	 * @Description: 获取userid
	 * @return String
	 */
	public String getUserId() {
		return super.getString(USER_ID);
	}
}
