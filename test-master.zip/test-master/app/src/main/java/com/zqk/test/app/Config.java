package com.zqk.test.app;

/**
 * TODO<配置>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:29:44
 * @version: V1.0
 */
public class Config {

	/**
	 * 一页请求的个数
	 */
	public static final int DEFAULT_PAGE_SIZE = 10;

	/**
	 * http请求地址头
	 */
	public static String HTTP_URL = "http://112.11.11.11:8099/lushi/";

	public static String LOGIN = HTTP_URL+"api/user/login.json";

	public static String COMMENT_LIST = HTTP_URL+"api/userInfo/getEvaluationsByUserId.json;";
}
