package com.zqk.test.ui.activity.main;

import android.annotation.TargetApi;
import android.content.Intent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;

import com.framework.base.BaseWorkerFragmentActivity;
import com.zqk.test.R;
import com.zqk.test.data.cache.AppDataCache;
import com.zqk.test.ui.activity.login.LoginActivity;

/**
 * TODO<启动页>
 * 
 * @author zqk
 * @data: 2015年11月25日 下午11:10:53
 * @version: V1.0
 */
public class SplashActivity extends BaseWorkerFragmentActivity implements AnimationListener {

	@Override
	public void setCView() {

		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); // 设置全屏
		setTranslucentStatus(false);
		setContentView(R.layout.activity_splash);
		boolean isOpen= AppDataCache.getInstance().getBoolean("isOpen");
		if(!isOpen){
			AppDataCache.getInstance().putBoolean("isOpen", true);
			Intent it=new Intent(this,MainWelcomeActivity.class);
			startAnimationActivity(it);
			finish();
		}else{
			startAnmi();
		}
	}

	@TargetApi(19)
	private void setTranslucentStatus(boolean on) {
		Window win = getWindow();
		WindowManager.LayoutParams winParams = win.getAttributes();
		final int bits = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
		if (on) {
			winParams.flags |= bits;
		} else {
			winParams.flags &= ~bits;
		}
		win.setAttributes(winParams);
	}

	@Override
	public void initView() {

	}

	@Override
	public void initData() {

	}

	private void startAnmi() {
		ImageView iv = (ImageView) findViewById(R.id.iv_splash);
		AlphaAnimation anmi = new AlphaAnimation(0.5f, 1.0f);
		anmi.setFillAfter(true);
		anmi.setDuration(1000);
		anmi.setAnimationListener(this);
		iv.startAnimation(anmi);
	}

	@Override
	public void onAnimationStart(Animation animation) {
		/**
		 * 动画开始,如果有帐户名和密码就先自动登陆 autoLogin();
		 */
	}

	@Override
	public void onAnimationEnd(Animation animation) {
		/**
		 * 如果已经登陆了跳转到主页面 gotoMain();
		 */
		gotoLogin();
	}

	@Override
	public void onAnimationRepeat(Animation animation) {

	}

	/**
	 * @Title: gotoMain
	 * @Description: TODO(已经登陆跳转到主页面)
	 * @return void
	 */
	private void gotoMain() {
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
		finishAnimationActivity();
	}

	/**
	 * @Title: gotoLogin
	 * @Description: TODO(没有登录跳转到登陆页面)
	 * @return void
	 */
	private void gotoLogin() {
		Intent intent = new Intent(this, LoginActivity.class);
		startActivity(intent);
		finishAnimationActivity();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}


}
