package com.zqk.test.logic.listener;

/** 
 * TODO<加载提示的监听器> 
 * @author zqk
 * @data:  2015年8月23日 下午4:36:36 
 * @version:  V1.0 
 */
public interface ITipsLayoutListener {

	// *************************************************************************
	/**
	 * 【】(提示页面的点击监听器)
	 * 
	 * @param btnId
	 */
	// *************************************************************************
	public void onTipLayoutClick(int btnId);

}
