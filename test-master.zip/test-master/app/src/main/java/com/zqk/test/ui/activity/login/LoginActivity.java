package com.zqk.test.ui.activity.login;

import android.content.Intent;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.framework.base.BaseWorkerFragmentActivity;
import com.zqk.test.R;
import com.zqk.test.app.Config;
import com.zqk.test.app.FragmentActivityManager;
import com.zqk.test.logic.business.HttpParamHelper;
import com.zqk.test.logic.business.HttpParseHelper;
import com.zqk.test.ui.activity.main.MainActivity;

/**
 * TODO<登陆>
 *
 * @author zqk
 * @data: 2015年11月25日 下午11:11:43
 * @version: V1.0
 */
public class LoginActivity extends BaseWorkerFragmentActivity {

    private EditText et_account, et_password;
    private TextView tv_register, tv_forget;
    private Button btn_login;
    private TextView tv_title;
    private final static int MSG_BACK_LOGIN = 0X01;
    private final static int MSG_UI_LOGIN_SUCCESS = 0X02;
    private final static int MSG_UI_LOGIN_FAILED = 0X03;
    private final static int MSG_UI_GOTO_MAIN = 0X04;


    @Override
    public void setCView() {
        setContentView(R.layout.activity_login);
    }

    @Override
    public void initView() {
        et_account = (EditText) findViewById(R.id.et_account);
        et_password = (EditText) findViewById(R.id.et_password);
        tv_register = (TextView) findViewById(R.id.tv_register);
        tv_forget = (TextView) findViewById(R.id.tv_forget);
        btn_login = (Button) findViewById(R.id.btn_login);
        tv_title = (TextView) findViewById(R.id.tv_title);

        tv_register.setOnClickListener(this);
        tv_forget.setOnClickListener(this);
        btn_login.setOnClickListener(this);
    }

    @Override
    public void initData() {
        tv_title.setText("登录");
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
            case R.id.btn_login:
                showLoadingDialog("登录中...");
                sendEmptyBackgroundMessage(MSG_BACK_LOGIN);
                break;
            case R.id.tv_register:
                break;
            case R.id.tv_forget:
                break;
        }
    }


    private void login() {
        post(this,
                Config.LOGIN, HttpParamHelper.getInstance().getLoginRequestParm(et_account.getText().toString(), et_password.getText().toString()),
                MSG_UI_LOGIN_SUCCESS, MSG_UI_LOGIN_FAILED);
    }

    @Override
    public void handleBackgroundMessage(Message msg) {
        switch (msg.what) {
            case MSG_BACK_LOGIN:
                login();
                break;
        }
    }

    @Override
    public void handleUiMessage(Message msg) {
        switch (msg.what) {
            case MSG_UI_LOGIN_FAILED:
                dismissLoadingDialog();
                showToast(msg.obj.toString());
                break;
            case MSG_UI_LOGIN_SUCCESS:
                dismissLoadingDialog();
                showToast("登录成功");
                HttpParseHelper.getInstance().parseUser(msg.obj.toString());
                sendEmptyUiMessageDelayed(MSG_UI_GOTO_MAIN, 500);
                break;
            case MSG_UI_GOTO_MAIN:
                FragmentActivityManager.getActivityManager().finishAllActivity();
                Intent it = new Intent(this, MainActivity.class);
                startAnimationActivity(it);
                break;
        }
    }

}
