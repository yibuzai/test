package com.zqk.test.logic.listener;

public interface ISelectedPageChange {
	
	public void onPageSelected(int curPage, int nextPage, Object message);

}
