package com.zqk.test.data.enitity;

import com.google.gson.annotations.SerializedName;

/**
 * TODO<用户属性>
 * 
 * @author zqk
 * @data: 2015年8月3日 下午11:13:52
 * @version: V1.0
 */
public class UserEnitity {


	/**
	 * age : 0
	 * amount : 0
	 * app_type : 0
	 * class : com.metronic.framework.entity.api.AppUser
	 * createDate : 2016-01-12 09:29:35
	 * head_url : /res-storage/m1/7A/44/2176aa1002d8b8dcaa7dc64ca4ce8c85.jpg
	 * id : 27
	 * lastAccessTime : 2016-01-12 09:29:35
	 * latitude :
	 * longitude :
	 * modifyDate : 2016-07-08 17:44:53
	 * name : 测试3
	 * password : e10adc3949ba59abbe56e057f20f883e
	 * pay_pwd : 0
	 * phone : 13570310385
	 * point : 1180
	 * sex : 1
	 * status : 1
	 */

	private AppUser appUser;
	/**
	 * appUser : {"age":0,"amount":0,"app_type":0,"class":"com.metronic.framework.entity.api.AppUser","createDate":"2016-01-12 09:29:35","head_url":"/res-storage/m1/7A/44/2176aa1002d8b8dcaa7dc64ca4ce8c85.jpg","id":27,"lastAccessTime":"2016-01-12 09:29:35","latitude":"","longitude":"","modifyDate":"2016-07-08 17:44:53","name":"测试3","password":"e10adc3949ba59abbe56e057f20f883e","pay_pwd":0,"phone":"13570310385","point":1180,"sex":1,"status":1}
	 * sessionId : 08d6d834dd0025a9faf14fa57a85fe92
	 */

	private String sessionId;

	public AppUser getAppUser() {
		return appUser;
	}

	public void setAppUser(AppUser appUser) {
		this.appUser = appUser;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public static class AppUser {
		private String age;
		private String amount;
		private String app_type;
		@SerializedName("class")
		private String classX;
		private String createDate;
		private String head_url;
		private int id;
		private String lastAccessTime;
		private String latitude;
		private String longitude;
		private String modifyDate;
		private String name;
		private String password;
		private String pay_pwd;
		private String phone;
		private String point;
		private int sex;
		private int status;

		public String getAge() {
			return age;
		}

		public void setAge(String age) {
			this.age = age;
		}

		public String getAmount() {
			return amount;
		}

		public void setAmount(String amount) {
			this.amount = amount;
		}

		public String getApp_type() {
			return app_type;
		}

		public void setApp_type(String app_type) {
			this.app_type = app_type;
		}

		public String getClassX() {
			return classX;
		}

		public void setClassX(String classX) {
			this.classX = classX;
		}

		public String getCreateDate() {
			return createDate;
		}

		public void setCreateDate(String createDate) {
			this.createDate = createDate;
		}

		public String getHead_url() {
			return head_url;
		}

		public void setHead_url(String head_url) {
			this.head_url = head_url;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getLastAccessTime() {
			return lastAccessTime;
		}

		public void setLastAccessTime(String lastAccessTime) {
			this.lastAccessTime = lastAccessTime;
		}

		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}

		public String getModifyDate() {
			return modifyDate;
		}

		public void setModifyDate(String modifyDate) {
			this.modifyDate = modifyDate;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public String getPay_pwd() {
			return pay_pwd;
		}

		public void setPay_pwd(String pay_pwd) {
			this.pay_pwd = pay_pwd;
		}

		public String getPhone() {
			return phone;
		}

		public void setPhone(String phone) {
			this.phone = phone;
		}

		public String getPoint() {
			return point;
		}

		public void setPoint(String point) {
			this.point = point;
		}

		public int getSex() {
			return sex;
		}

		public void setSex(int sex) {
			this.sex = sex;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}
	}
}
