package com.zqk.test.ui.activity.main;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.framework.base.BaseWorkerFragment;
import com.zqk.test.R;
import com.zqk.test.logic.listener.IMainPageChangeObserver;

/** 
 * TODO<主页-圈子> 
 * @author zqk
 * @data: 2016年03月11日 下午11:22:40
 * @version: V1.0
 */
public class MainContactsPageFragment extends BaseWorkerFragment implements View.OnClickListener,IMainPageChangeObserver {
	private TextView tv_title;

	@Override
	protected int setCView() {
		return R.layout.fragment_main_mine_page;
	}

	@Override
	protected void initView(View view) {
		tv_title = (TextView) view.findViewById(R.id.tv_title);
	}

	@Override
	protected void initData() {
		tv_title.setText("我");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {

		}
	}

	@Override
	public void onMainPageChange(Context context, int index) {

	}
}
