package com.zqk.test.logic.business;

import com.framework.util.StringUtil;
import com.google.gson.Gson;
import com.zqk.test.data.enitity.CommentEnitity;
import com.zqk.test.data.enitity.UserEnitity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO<解析所有http请求结果的参数逻辑类>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:34:24
 * @version: V1.0
 */
public class HttpParseHelper {

	private static HttpParseHelper sHttpParseHelper;

	public static synchronized HttpParseHelper getInstance() {
		if (sHttpParseHelper == null) {
			sHttpParseHelper = new HttpParseHelper();
		}
		return sHttpParseHelper;
	}
	
	/** 
	* @Title: parseUser 
	* @Description: TODO(解析用户属性) 
	* @param  result
	* @return UserEnitity   
	*/
	public UserEnitity parseUser(String result) {
		UserEnitity user = null;
		if (StringUtil.isEmpty(result))
			return user;
		try {
			JSONObject json = new JSONObject(result);
			JSONObject data = json.optJSONObject("data");
			Gson gson = new Gson();

			user = gson.fromJson(data.toString(), UserEnitity.class);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return user;
	}

	/**
	 * @Title: parseCommentList
	 * @Description: TODO(解析评论列表)
	 * @param result
	 * @return List<CommentEnitity>
	 */
	public List<CommentEnitity> parseCommentList(String result) {
		List<CommentEnitity> recordList = new ArrayList<CommentEnitity>();

		if (StringUtil.isEmpty(result))
			return recordList;
		try {
			JSONObject json = new JSONObject(result);
			JSONObject object = json.optJSONObject("object");

			JSONArray list = object.optJSONArray("evaluations");

			if (list != null && list.length() > 0) {

				Gson gson = new Gson();

				for (int i = 0; i < list.length(); i++) {
					CommentEnitity enitity = gson.fromJson(list.optJSONObject(i).toString(), CommentEnitity.class);
					recordList.add(enitity);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return recordList;
	}
}