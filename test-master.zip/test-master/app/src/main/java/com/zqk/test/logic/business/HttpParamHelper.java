package com.zqk.test.logic.business;

import java.util.Hashtable;

/**
 * TODO<获取所有http请求的参数逻辑类>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:33:54
 * @version: V1.0
 */
public class HttpParamHelper {

	private static HttpParamHelper sHttpParamHelper;

	public static synchronized HttpParamHelper getInstance() {
		if (sHttpParamHelper == null) {
			sHttpParamHelper = new HttpParamHelper();
		}
		return sHttpParamHelper;
	}

	/**
	 * @Title: getLoginRequestParm
	 * @Description: TODO(登陆)
	 * @param userName
	 * @param password
	 * @return Hashtable<String,Object>
	 */
	public Hashtable<String, Object> getLoginRequestParm(String userName,
			String password) {
		Hashtable<String, Object> params = new Hashtable<String, Object>();
		params.put("phone", userName);
		params.put("password", password);
		params.put("type", 0);
		return params;
	}

	public Hashtable<String, Object> getMyCommentListRequestParm(int page) {
		Hashtable<String, Object> params = new Hashtable<String, Object>();
		params.put("id", "27");
		params.put("pageNumber", page);
		params.put("app_type", 0);
		return params;
	}
}
