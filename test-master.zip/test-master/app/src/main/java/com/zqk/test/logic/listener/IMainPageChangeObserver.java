package com.zqk.test.logic.listener;

import android.content.Context;

public interface IMainPageChangeObserver {

	public void onMainPageChange(Context context, int index);
	
}
