package com.zqk.test.app;

import android.content.Context;

import com.framework.base.BaseApplication;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

import java.io.File;

/** 
 * TODO<框架程序> 
 * @author zqk
 * @data:  2015年8月23日 下午3:56:28 
 * @version:  V1.0 
 */
public class ZbApplication extends BaseApplication{

	private static ZbApplication sApplication;

	/**
	 * @Title: getInstance
	 * @Description: TODO(获取单例)
	 * @return ZbApplication
	 */
	public static ZbApplication getInstance() {
		if (sApplication == null) {
			throw new IllegalStateException("Application is not created.");
		}
		return sApplication;
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		sApplication=this;
		// 初始化文件目录
		SdcardConfig.getInstance().initSdcard();
		// 捕捉异常
		Thread.setDefaultUncaughtExceptionHandler(AppUncaughtExceptionHandler
				.getInstance());
		// 初始化activity管理
		FragmentActivityManager.initActivityManager();
		// 初始化图片加载类
		initImageLoader(getApplicationContext());
	}

	// *************************************************************************
	/**
	 * 【】(退出程序)
	 */
	// *************************************************************************
	public void exit() {
		FragmentActivityManager.getActivityManager().finishAllActivity();
	}

	// *************************************************************************
	/**
	 * 【】(初始化图片加载器)
	 * 
	 * @param context
	 */
	// *************************************************************************
	private void initImageLoader(Context context) {
		File cacheDir = new File(SdcardConfig.CACHE_FOLDER);
		if (!cacheDir.exists()) {
			cacheDir.mkdirs();
		}

		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				context).threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.discCache(new UnlimitedDiscCache(cacheDir))
				.diskCacheFileNameGenerator(new Md5FileNameGenerator())
				.tasksProcessingOrder(QueueProcessingType.LIFO).build();
		ImageLoader.getInstance().init(config);
	}
}
