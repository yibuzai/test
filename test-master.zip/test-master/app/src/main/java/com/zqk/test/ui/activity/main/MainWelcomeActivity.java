package com.zqk.test.ui.activity.main;

import android.content.Intent;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;

import com.framework.base.BaseWorkerFragmentActivity;
import com.framework.util.ScreenUtil;
import com.zqk.test.R;
import com.zqk.test.ui.activity.login.LoginActivity;
import com.zqk.test.ui.adapter.WelcomePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO<欢迎页面>
 * 
 * @author zqk
 * @data: 2015年10月24日 上午9:57:50
 * @version: V1.0
 */
public class MainWelcomeActivity extends BaseWorkerFragmentActivity {

	private final static int MSG_UI_GOTO_LOGIN = 0X01;

	private ViewPager mVpWelcome;
	private LinearLayout mLlContainer;

	/**
	 * 视图数组
	 */
	private List<View> mGuideViewList = new ArrayList<View>();
	private List<Integer> mImageResList = new ArrayList<Integer>();
	private int mCurPos;


	@Override
	public void setCView() {
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); // 设置全屏
		setContentView(R.layout.activity_main_welcome);
	}

	@Override
	public void initView() {
		mVpWelcome = (ViewPager) findViewById(R.id.vp_welcome);
		mLlContainer = (LinearLayout) findViewById(R.id.ll_container);
	}

	@Override
	public void initData() {

		mImageResList.add(R.mipmap.bg_splash);
		mImageResList.add(R.mipmap.bg_splash2);
		mImageResList.add(R.mipmap.bg_splash3);

		LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(ScreenUtil.dip2px(6), ScreenUtil.dip2px(6));
		dotLp.setMargins(ScreenUtil.dip2px(3), 0, ScreenUtil.dip2px(3), 0);

		for (int i = 0; i < mImageResList.size(); i++) {

			ImageView iv = new ImageView(this);

			iv.setImageResource(mImageResList.get(i));

			ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
					ViewGroup.LayoutParams.MATCH_PARENT);
			iv.setLayoutParams(params);
			iv.setScaleType(ScaleType.CENTER_CROP);

			mGuideViewList.add(iv);

			ImageView dot = new ImageView(this);
			if (i == 0)
				dot.setImageResource(R.mipmap.ic_welcome_cur_dot);
			else
				dot.setImageResource(R.mipmap.ic_welcome_dot);
			dot.setScaleType(ScaleType.FIT_XY);
			mLlContainer.addView(dot, dotLp);
		}

		WelcomePagerAdapter adapter = new WelcomePagerAdapter(mGuideViewList);

		mVpWelcome.setAdapter(adapter);
		mVpWelcome.setOnPageChangeListener(new OnPageChangeListener() {
			public void onPageSelected(int arg0) {
				((ImageView) mLlContainer.getChildAt(mCurPos)).setImageResource(R.mipmap.ic_welcome_dot);
				((ImageView) mLlContainer.getChildAt(arg0)).setImageResource(R.mipmap.ic_welcome_cur_dot);
				mCurPos = arg0;

				if (mCurPos == mImageResList.size() - 1)
					sendEmptyUiMessageDelayed(MSG_UI_GOTO_LOGIN, 300);
			}

			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}

			public void onPageScrollStateChanged(int arg0) {
			}

		});

	}

	protected void handleUiMessage(Message msg) {
		switch (msg.what) {
		case MSG_UI_GOTO_LOGIN:
			gotoLogin();
			break;
		}
	}

	private void gotoLogin() {
		Intent intent = new Intent(this, LoginActivity.class);
		startActivity(intent);
		finishAnimationActivity();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

}
