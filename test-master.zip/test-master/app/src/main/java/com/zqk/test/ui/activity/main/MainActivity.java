package com.zqk.test.ui.activity.main;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.View;

import com.framework.base.BaseWorkerFragmentActivity;
import com.framework.util.LogUtils;
import com.zqk.test.R;
import com.zqk.test.app.ZbApplication;
import com.zqk.test.logic.listener.IMainPageChangeObserver;
import com.zqk.test.logic.listener.ISelectedPageChange;
import com.zqk.test.ui.adapter.FragmentTabAdapter;
import com.zqk.test.ui.widget.custom.CustomRadioGroup;
import com.zqk.test.ui.widget.dialog.TipDialog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by thinkpad on 2016/11/28.
 */
public class MainActivity extends BaseWorkerFragmentActivity implements ISelectedPageChange {
    public static final String TAG = MainActivity.class.getSimpleName();

    private CustomRadioGroup mBottomTabHost;
    private List<Fragment> mFragments = new ArrayList<Fragment>();

    private List<IMainPageChangeObserver> mMainPageChangeObservers;
    private FragmentTabAdapter mFragmentTabAdapter;

    @Override
    public void setCView() {
        setContentView(R.layout.activity_home);
    }

    @Override
    public void initView() {
        mFragments.add(new MainHomePageFragment());
        mFragments.add(new MainContactsPageFragment());
        mFragments.add(new MainMinePageFragment());
        mBottomTabHost = (CustomRadioGroup) findViewById(R.id.main_bottom_bar);
        mFragmentTabAdapter = new FragmentTabAdapter(this, mFragments, R.id.main_content_fragment, mBottomTabHost);
    }

    @Override
    public void initData() {
        mMainPageChangeObservers = new ArrayList<IMainPageChangeObserver>();
        mMainPageChangeObservers.add((IMainPageChangeObserver) mFragments.get(0));
        mMainPageChangeObservers.add((IMainPageChangeObserver) mFragments.get(1));
        mMainPageChangeObservers.add((IMainPageChangeObserver) mFragments.get(2));
        mFragmentTabAdapter.setOnRgsExtraCheckedChangedListener(new FragmentTabAdapter.OnRgsExtraCheckedChangedListener() {
            @Override
            public void OnRgsExtraCheckedChanged(CustomRadioGroup radioGroup,
                                                 int checkedId, int index) {
                notifyAllObservers(mContext, index);
            }
        });
    }

    private void notifyAllObservers(Context context, int index) {
        if(mMainPageChangeObservers != null && mMainPageChangeObservers.size() > 0) {
            for(IMainPageChangeObserver observer: mMainPageChangeObservers) {
                observer.onMainPageChange(context, index);
            }
        }
    }

    @Override
    public void onPageSelected(int curPage, int nextPage, Object message) {
        if(message != null) LogUtils.d(TAG, String.valueOf(message));
        if(curPage != nextPage && mBottomTabHost != null) {
            switch(nextPage) {
                case 0:
                    mBottomTabHost.check(R.id.main_tab_home);
                    break;
                case 1:
                    mBottomTabHost.check(R.id.main_tab_contacts);
                    break;
                case 2:
                    mBottomTabHost.check(R.id.main_tab_mine);
                    break;
            }
        }
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
            case R.id.dialog_btn_sure:
                /**
                 * 退出应用程序
                 */
                finishAnimationActivity();
                ZbApplication.getInstance().exit();
                break;
        }
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            TipDialog mTipDialog = new TipDialog(this, this);
            mTipDialog.setMessage("确定退出程序吗?");
            mTipDialog.show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}