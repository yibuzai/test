package com.zqk.test.ui.base;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.List;

/**
 * TODO<通用的CommonAdapter类>
 *
 * @author zqk
 * @data: 2015年8月24日 下午2:11:39
 * @version: V1.0
 */

public abstract class CommonAdapter<T> extends BaseAdapter {
    protected View view = null;
    protected LayoutInflater mInflater;
    protected Context mContext;
    protected List<T> mDatas;
    protected int mItemLayoutId;

    public CommonAdapter(Context mContext, List<T> mDatas, View view) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        this.view = view;
    }

    public CommonAdapter(Context mContext, List<T> mDatas, int mItemLayoutId) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        this.mItemLayoutId = mItemLayoutId;
    }

    @Override
    public int getCount() {
        return mDatas.size();
    }

    @Override
    public T getItem(int position) {
        return mDatas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (view == null) {
            viewHolder = ViewHolder.get(mContext, convertView, parent,
                    mItemLayoutId, position);

        } else {
            viewHolder = ViewHolder.get(mContext, convertView, parent, view,
                    position);
        }

        convert(viewHolder, getItem(position), position);
        return viewHolder.getConvertView();
    }

    public abstract void convert(ViewHolder helper, T item, int position);

}
