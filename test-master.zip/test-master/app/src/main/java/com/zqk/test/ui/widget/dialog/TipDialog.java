package com.zqk.test.ui.widget.dialog;

import com.framework.util.ScreenUtil;
import com.zqk.test.R;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * TODO<提示dialog>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:08:24
 * @version: V1.0
 */
public class TipDialog extends Dialog {

	private TextView mTvMessage;
	private Button mBtnCancel;
	private Button mBtnSure;
	private LinearLayout mLlTitle;
	private TextView mTvTitle;
	private LinearLayout mLlContent;

	private Context mContext;
	private View.OnClickListener mListener;

	public TipDialog(Context context, View.OnClickListener listener) {
		super(context, R.style.Alert_Dialog_Style);
		mListener = listener;
		mContext = context;
		init(context);
	}

	private void init(Context context) {
		setCanceledOnTouchOutside(false);

		View view = View.inflate(context, R.layout.widget_dialog_tip, null);
		setContentView(view);
		init(view);
	}

	private void init(View view) {
		mLlTitle = (LinearLayout) view.findViewById(R.id.ll_title);
		mLlTitle.setVisibility(View.GONE);
		mLlContent = (LinearLayout) view.findViewById(R.id.ll_content);
		mTvTitle = (TextView) view.findViewById(R.id.tv_title);
		mTvMessage = (TextView) view.findViewById(R.id.tv_message);
		mBtnCancel = (Button) view.findViewById(R.id.dialog_btn_cancel);
		mBtnSure = (Button) view.findViewById(R.id.dialog_btn_sure);
		mBtnSure.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				dismiss();
				if (mListener != null)
					mListener.onClick(arg0);

			}
		});
		mBtnCancel.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				dismiss();
				if (mListener != null)
					mListener.onClick(arg0);

			}
		});

		Window window = getWindow();
		WindowManager.LayoutParams params = window.getAttributes();
		params.gravity = Gravity.CENTER;
		params.alpha = 1.0f;
		params.width = ScreenUtil.getScreenWidth();
		window.setAttributes(params);
	}

	/**
	 * 设置标题
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		mLlTitle.setVisibility(View.VISIBLE);
		mTvTitle.setText(title);
		mLlContent.setBackgroundResource(R.drawable.common_white);
	}

	/**
	 * 设置内容
	 * 
	 * @param message
	 */
	public void setMessage(String message) {
		mTvMessage.setText(message);
	}

	/**
	 * 设置确认按钮的文字
	 * 
	 * @param sure
	 */
	public void setBtnSure(String sure) {
		mBtnSure.setText(sure);
	}

	/**
	 * 设置取消按钮的文字
	 * 
	 * @param cancel
	 */
	public void setBtnCancel(String cancel) {
		mBtnCancel.setText(cancel);
	}

	/**
	 * 设置取消按钮的文字
	 * 
	 * @param visible
	 */
	public void setBtnCancelVisible(int visible) {
		mBtnCancel.setVisibility(visible);
		if (visible == View.GONE) {
			mBtnSure.setBackgroundResource(R.drawable.selector_btn_white_bottom_corner);
		} else {
			mBtnSure.setBackgroundResource(R.drawable.selector_btn_white_right_corner);
		}
	}

	/**
	 * 设置标题的颜色
	 * 
	 * @param color
	 */
	public void setTitleColor(int color) {
		mTvTitle.setTextColor(color);
	}

	/**
	 * 设置内容的颜色
	 * 
	 * @param color
	 */
	public void setMessageColor(int color) {
		mTvMessage.setTextColor(color);
	}

	/**
	 * 确认按钮的颜色
	 * 
	 * @param color
	 */
	public void setBtnSureColor(int color) {
		mBtnSure.setTextColor(color);
	}

	/**
	 * 确认取消的颜色
	 * 
	 * @param color
	 */
	public void setBtnCalcelColor(int color) {
		mBtnCancel.setTextColor(color);
	}

	/**
	 * 设置自定义的view
	 * 
	 * @param contentView
	 */
	public void setCustomContentView(View contentView) {
		mLlContent.removeAllViews();
		mLlContent.addView(contentView);
	}

	/**
	 * 设置确认是否有效
	 * 
	 * @param enabled
	 */
	public void setBtnSureEnable(boolean enabled) {
		mBtnSure.setEnabled(enabled);
		if (!enabled) {
			mBtnSure.setTextColor(mContext.getResources().getColor(
					R.color.light_black));
		}
	}

	/**
	 * 设置取消是否有效
	 * 
	 * @param enabled
	 */
	public void setBtnCancelEnable(boolean enabled) {
		mBtnCancel.setEnabled(enabled);
		if (!enabled) {
			mBtnCancel.setTextColor(mContext.getResources().getColor(
					R.color.light_black));
		}
	}
}
