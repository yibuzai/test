package com.zqk.test.data.enitity;

import com.framework.base.BaseEnitity;

import java.util.List;

/**
 * TODO<评价属性>
 * 
 * @author zqk
 * @data: 2016年1月6日 上午10:13:41
 * @version: V1.0
 */
public class CommentEnitity extends BaseEnitity {

	private static final long serialVersionUID = 375975506718245797L;

	private String content;// ":"content1",
	private String createDate;// ":"2015-12-28 19:33:24",
	private double degree;// ":1,
	private String evaluation_id;// ":1,
	private List<String> file_urls;//
	private String head_url;// ":"",
	private String modifyDate;// ":"2015-12-28 19:33:24",
	private String name;// ":"",
	private String user_id;// ":21

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public double getDegree() {
		return degree;
	}

	public void setDegree(double degree) {
		this.degree = degree;
	}

	public String getEvaluation_id() {
		return evaluation_id;
	}

	public void setEvaluation_id(String evaluation_id) {
		this.evaluation_id = evaluation_id;
	}

	public List<String> getFile_urls() {
		return file_urls;
	}

	public void setFile_urls(List<String> file_urls) {
		this.file_urls = file_urls;
	}

	public String getHead_url() {
		return head_url;
	}

	public void setHead_url(String head_url) {
		this.head_url = head_url;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

}
