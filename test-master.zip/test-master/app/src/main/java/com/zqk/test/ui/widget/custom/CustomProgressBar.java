package com.zqk.test.ui.widget.custom;

import com.zqk.test.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

/**
 * TODO<等待条>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:10:04
 * @version: V1.0
 */
public class CustomProgressBar extends ImageView {

	public CustomProgressBar(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	public void setVisibility(int visibility) {
		super.setVisibility(visibility);
		if (visibility == View.VISIBLE) {
			Animation hyperspaceJumpAnimation = AnimationUtils.loadAnimation(
					getContext(), R.anim.custom_progressbar);
			// 使用ImageView显示动画
			startAnimation(hyperspaceJumpAnimation);
		} else {
			clearAnimation();
		}
	}
}
