package com.zqk.test.ui.widget.dialog;

import com.zqk.test.R;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * TODO<加载dialog>
 * 
 * @author zqk
 * @data: 2015年8月23日 下午4:05:13
 * @version: V1.0
 */
public class LoadingDialog extends Dialog {

	private TextView mTvMessage = null;

	public LoadingDialog(Context context) {
		super(context, R.style.Alert_Dialog_Style);
		initProgressDialog(context);
	}

	private void initProgressDialog(Context context) {
		setCanceledOnTouchOutside(false);

		View view = View.inflate(context, R.layout.widget_dialog_loading, null);
		setContentView(view);

		mTvMessage = (TextView) view.findViewById(R.id.tv_message);

		Window window = getWindow();
		WindowManager.LayoutParams params = window.getAttributes();
		params.gravity = Gravity.CENTER;
		params.alpha = 1.0f;
		params.width = -2;
		params.height = -2;
		window.setAttributes(params);
	}

	public void setMessage(String msg) {
		mTvMessage.setText(msg);
	}
}
