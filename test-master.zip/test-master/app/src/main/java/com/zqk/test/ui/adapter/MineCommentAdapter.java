package com.zqk.test.ui.adapter;

import android.content.Context;
import android.view.View;

import com.framework.util.StringUtil;
import com.zqk.test.R;
import com.zqk.test.app.Config;
import com.zqk.test.data.enitity.CommentEnitity;
import com.zqk.test.logic.listener.IAdapterClickListener;
import com.zqk.test.ui.base.CommonAdapter;
import com.zqk.test.ui.base.ViewHolder;

import java.util.List;

public class MineCommentAdapter extends CommonAdapter<CommentEnitity> {

	private IAdapterClickListener mIAdapterClickListener;

	public void setIAdapterClickListener(IAdapterClickListener listener) {
		mIAdapterClickListener = listener;
	}

	public MineCommentAdapter(Context mContext, List<CommentEnitity> mDatas, int mItemLayoutId) {
		super(mContext, mDatas, mItemLayoutId);
	}

	@Override
	public void convert(ViewHolder helper, CommentEnitity item, final int position) {
		helper.getView(R.id.iv_user).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (mIAdapterClickListener != null) {
					mIAdapterClickListener.adapterClick(view.getId(), position);
				}
			}
		});

		helper.setText(R.id.tv_name,item.getName());
		helper.setText(R.id.tv_content,item.getContent());
		helper.setText(R.id.tv_time,item.getCreateDate());

		String tempHeadUrl = "";
		if (!StringUtil.isEmpty(item.getHead_url()) && item.getHead_url().contains("http")) {
			tempHeadUrl = item.getHead_url();
		} else {
			tempHeadUrl = Config.HTTP_URL + item.getHead_url();
		}
		helper.setImageByUrl(R.id.iv_user,tempHeadUrl);

		helper.setImageResource(R.id.iv_star1,item.getDegree() >= 1 ? R.mipmap.ic_star_orange : R.mipmap.ic_star_gray);
		helper.setImageResource(R.id.iv_star2,item.getDegree() >= 2 ? R.mipmap.ic_star_orange : R.mipmap.ic_star_gray);
		helper.setImageResource(R.id.iv_star3,item.getDegree() >= 3 ? R.mipmap.ic_star_orange : R.mipmap.ic_star_gray);
		helper.setImageResource(R.id.iv_star4,item.getDegree() >= 4 ? R.mipmap.ic_star_orange : R.mipmap.ic_star_gray);
		helper.setImageResource(R.id.iv_star5,item.getDegree() >= 5 ? R.mipmap.ic_star_orange : R.mipmap.ic_star_gray);


	}

}
