package com.zqk.test.ui.adapter;


import android.content.Context;
import android.view.View;

import com.zqk.test.R;
import com.zqk.test.logic.listener.IAdapterClickListener;
import com.zqk.test.ui.base.CommonAdapter;
import com.zqk.test.ui.base.ViewHolder;

import java.util.List;

public class OrderAdapter extends CommonAdapter<String> {

    private IAdapterClickListener mIAdapterClickListener;

    public void setIAdapterClickListener(IAdapterClickListener listener) {
        mIAdapterClickListener = listener;
    }

    public OrderAdapter(Context mContext, List<String> mDatas, int mItemLayoutId) {
        super(mContext, mDatas, mItemLayoutId);
    }

    @Override
    public void convert(ViewHolder helper, String item, final int position) {
        helper.setText(R.id.no,"ddddddddddddd");
        helper.getView(R.id.no).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mIAdapterClickListener != null) {
                    mIAdapterClickListener.adapterClick(view.getId(), position);
                }
            }
        });
    }

}
